library(pracma)
library(readxl)
library(fGarch)
library(fBasics)
library(devtools)
library(pracma)
library(plotly)
library(lubridate)
library(htmlwidgets)
library(htmltools)
library(timeSeries)
rm(list = ls())

# make the path 
gen_path<-"~/"  #Specific to the computer

#Relative to gen path
path <- paste(gen_path,"Dropbox/2023_Side_Summer_School_Macro_Forecasting_in_ML_Era/Lectures/GouletCoulombe/Codes/TVP-VAR-2SRR/",sep="")

# import dataset
dataset_Canada <- read_excel(paste(path,'dataset_Canada.xls',sep=""))

#import function
source(file.path(path,"TVP-VAR-2SRR.R"))

#number of lags
vlag = 6

# Create the X matrix and Y matrix
dataset <- fXMAT(as.matrix(dataset_Canada),vlag)
Ymat = dataset$Ymat[1:400,]
Xmat = dataset$Xmat[1:400,]

# estimate TVP-VAR-2SRR
results1 <- tvp.ridge(Xmat,Ymat,block_size = 24,lambda.candidates =exp(linspace(1,20,n=10)))
RES<-Ymat-results1$yhat.2srr

# generate the IRF
results2 <- VAR_tvpIRF(results1$betas.2srr,RES,48,4,1:4)

# generate the graph
graph3D <- fancyIRF(results2,colnames(dataset_Canada))


