

TVP-VAR-2SSR is a time-varying parameter VAR model that utilizes a two-step Ridge regression approach, as proposed by Goulet Coulombe in his 2021 paper titled "Time-Varying Parameters as Ridge Regressions."

In the folder provided, there are three files:

1. dataset_Canada.xls: 		This file contains the dataset with eight variables that will be used 				for the TVP-VAR-2SRR analysis.

2. TVP-VAR-2SRR.R: 		This file includes all the necessary functions for estimating the 				VAR,generating the impulse response function, and creating a 3D graph 				that displays the IRF.

3. Generate_IRF_example.R: 	This file contains the necessary steps to generate the 3D graph using 				the TVP-VAR-2SRR approach with the data from dataset_Canada.xls. 




Code contributors (2)
---------------------

- Christophe Barette (christophebarrette@gmail.com)
- Philippe Goulet-Coulombe (p.gouletcoulombe@gmail.com)