MACE <- function(backpack_data,backpack_hyps){
  
  
  
  # --- Unpack the data
  X_train <- backpack_data[['X_train']]
  X_test <- backpack_data[['X_test']]
  
  Y_train <- backpack_data[['Y_train']]
  Y_test <- backpack_data[['Y_test']]
  
  
  # --- Get the time-dimensions of the respective sets:
  TT_train <- dim(X_train)[1]
  TT_test <- dim(X_test)[1]
  
  
  # --- Some preliminary dataframes:
  rmse_train_Bdf <- data.frame(matrix(NA,nrow=backpack_hyps[['maxit']],ncol=backpack_hyps[['B']],
                                      dimnames = list(c(),paste0("B",c(1:backpack_hyps[['B']])))))
  rsq_train_Bdf <- data.frame(matrix(NA,nrow=backpack_hyps[['maxit']],ncol=backpack_hyps[['B']],
                                     dimnames = list(c(),paste0("B",c(1:backpack_hyps[['B']])))))
  rsq_test_Bdf <- data.frame(matrix(NA,nrow=backpack_hyps[['maxit']],ncol=backpack_hyps[['B']],
                                    dimnames = list(c(),paste0("B",c(1:backpack_hyps[['B']])))))
  hx_train_Bdf <- data.frame(matrix(NA,nrow=TT_train,ncol=backpack_hyps[['B']],
                                    dimnames = list(c(),paste0("B",c(1:backpack_hyps[['B']])))))
  hx_test_Bdf <- data.frame(matrix(NA,nrow=TT_test,ncol=backpack_hyps[['B']],
                                   dimnames = list(c(),paste0("B",c(1:backpack_hyps[['B']])))))
  hy_train_Bdf <- data.frame(matrix(NA,nrow=TT_train,ncol=backpack_hyps[['B']],
                                    dimnames = list(c(),paste0("B",c(1:backpack_hyps[['B']])))))
  hy_test_Bdf <- data.frame(matrix(NA,nrow=TT_test,ncol=backpack_hyps[['B']],
                                   dimnames = list(c(),paste0("B",c(1:backpack_hyps[['B']])))))
  fit_train_Bdf <- data.frame(matrix(NA,nrow=TT_train,ncol=backpack_hyps[['B']],
                                     dimnames = list(c(),paste0("B",c(1:backpack_hyps[['B']])))))
  fit_test_Bdf <- data.frame(matrix(NA,nrow=TT_test,ncol=backpack_hyps[['B']],
                                    dimnames = list(c(),paste0("B",c(1:backpack_hyps[['B']])))))
  
  # --- Vectors to store results
  my_run_Bvec <- rep(NA,times=backpack_hyps[['B']])
  R2_train_Bvec <- rep(NA,times=backpack_hyps[['B']])
  R2_test_Bvec <- rep(NA,times=backpack_hyps[['B']])
  
  # --- Lists to store results
  r1_hist_Blist <- rep(list(NA),times=backpack_hyps[['B']])
  r2_hist_Blist <- rep(list(NA),times=backpack_hyps[['B']])
  
  
  # --- Storage for portfolio-weights
  df_MACE_weights_Bdf <- data.frame(matrix(NA, nrow=backpack_hyps[['B']], 
                                           ncol=dim(Y_train)[2],dimnames=list(c(),colnames(Y_train))))
  
  # --- Storage for Predictions
  df_pred_Blist <- list('Train'=setNames(rep(list(data.frame(matrix(NA,
                                                                    nrow=TT_train,
                                                                    ncol=backpack_hyps[['B']],
                                                                    dimnames=list(c(),paste0("B",c(1:backpack_hyps[['B']])))))),
                                             times=6), c('MACE','MACE (PM)','EW (RF)', 'EW (PM)', 'SP500 (RF)', 'SP500 (PM)')),
                        'Test'=setNames(rep(list(data.frame(matrix(NA,
                                                                   nrow=TT_test,
                                                                   ncol=backpack_hyps[['B']],
                                                                   dimnames=list(c(),paste0("B",c(1:backpack_hyps[['B']])))))),
                                            times=6), c('MACE','MACE (PM)','EW (RF)', 'EW (PM)', 'SP500 (RF)', 'SP500 (PM)')))
  
  
  
  
  ################################################################################################
  #
  #                    1)       Run MACE (Algorithm 1 in  Goulet Coulombe & Goebel (2023))
  #
  ################################################################################################
  
  for (bags in 1:backpack_hyps[['B']]){  
    
    print(paste0("Running Bag ", bags,"/",backpack_hyps[['B']]))
    
    # --- Some preliminary storages:
    rsq_train_vec <- c()
    rsq_test_vec <- c()
    rmse_train_vec <- c()
    cor_train_vec <- c()
    
    r1_hist <- list() # List to store predictions
    r2_hist <- list() # List to store predictions
    
    # ---------------------------------------------------------------------------------------------------------- #
    #
    #                                     Algorithm 1 - Step 1   
    #                 -   Initialize 'z_0' (denoted: z2) as the scaled equally-weighted portfolio
    #                 -   Initialize 'f*_s' (denoted: z1) as a draw from N(0,1)
    #
    # ---------------------------------------------------------------------------------------------------------- #
    
    # --- Initialize 'z1' 
    z1 = rnorm(nrow(Y_train))
    # --- Initialize 'z2' 
    z2 = scale(apply(Y_train,1,mean))
    
    # --- Just for storage
    z1_df <- data.frame("z1_0"=z1)
    z2_df <- data.frame("z2_0"=z2)
    
    # --- Initialize portfolio-weights
    MACE_weights <- rep(1/ncol(Y_train),times=ncol(Y_train))
    
    
    # ---------------------------------------------------------------------------------------------------------- #
    #
    #                     Algorithm 1 - Step 2:   Loop until 's_max' (denoted: maxit)
    #
    # ---------------------------------------------------------------------------------------------------------- #
    
    
    for(i in 1:backpack_hyps[['maxit']]){
      
      
      print(paste0("Iteration ", i,'/', backpack_hyps[['maxit']] ," --- Bag ", bags,"/",backpack_hyps[['B']]))
      
      # ----------------------------------------------------------------------------------------------------- #
      #
      #                     Algorithm 1 - Step 3:  The Random Forest Step
      #
      # ----------------------------------------------------------------------------------------------------- #
      
      
      # --- Draw blocks of observations for Out-Of-Bag computations
      bs=block.sampler(X_train,sampling_rate=0.8, 
                       block_size=backpack_hyps[['my_blocksize']], 
                       num.tree=backpack_hyps[['my_trees']])
      
      
      # --- Fit the RHS to our portfolio
      ddd = as.data.frame(cbind(z=z2,X_train))
      colnames(ddd)[1]='z'
      r1 <- ranger(z ~ ., data = ddd,
                   num.trees=backpack_hyps[['my_trees']],
                   inbag=bs$inbag1,
                   min.node.size = backpack_hyps[['my_minnodesize']],
                   mtry=round(ncol(X_train)/backpack_hyps[['mtry_denom']]), 
                   #importance = 'impurity',
                   num.threads = 2)
      
      
      # ----------------------------------------------------------------------------------------------------- #
      #
      #                     Algorithm 1 - Step 4:  Update the RHS
      #
      # ----------------------------------------------------------------------------------------------------- #
      
      
      # --- --- Adjust 'z1'
      if(i>1){
        z1 = backpack_hyps[['lr']]*r1$predictions + (1-backpack_hyps[['lr']])*z1
      }else{
        z1 = backpack_hyps[['lr']]*as.vector((r1$predictions)) + (1-backpack_hyps[['lr']])*sd(r1$predictions)*z1
      }
      
      
      # ----------------------------------------------------------------------------------------------------- #
      #
      #                     Algorithm 1 - Step 5:  The Ridge Regression Step
      #
      # ----------------------------------------------------------------------------------------------------- #
      
      
      
      # --- Fit the LHS to 'z1'
      ddd= as.data.frame(cbind(z=z1,Y_train))
      colnames(ddd)[1]='z'
      # --- --- Stock-specific Penalty?
      if (backpack_hyps[['I_want_stockspecificpenalty']]){
        ssp <- as.vector(apply(Y_train,2,sd))
      } else {
        ssp <- rep(1, times=ncol(as.matrix(Y_train)))
      }
      # --- --- Observation weights?
      if (backpack_hyps[['I_want_obsweight']]){
        obsw <- (rexp(nrow(Y_train)))^(1/i)
        if(i>backpack_hyps[['maxit']]/3){obsw <- rep(1,nrow(Y_train))}
      } else {
        obsw <- rep(1,nrow(Y_train))
      }
      
      
      if (backpack_hyps[['I_want_lambda_targeting']]) {
        
        r2 = glmnet(Y_train, z1+backpack_hyps[['c0']], 
                    intercept = backpack_hyps[['I_want_intercept']], 
                    alpha=backpack_hyps[['my_alpha']], 
                    lower.limits = backpack_hyps[['my_lowerbound']], 
                    type.measure = "mse",
                    standardize=F,
                    standardize.response=F,
                    penalty.factor = ssp,
                    weights = obsw)
        
        all_lambdas <- r2$lambda
        
        if (backpack_hyps[['my_lambda_target']] == 'R2'){
          # --- Choose the lambda that best meets your R2-Target
          r2$lambda <- r2$lambda[order(abs(c(r2$dev.ratio-backpack_hyps[['my_R2_target']])))[1]]
        } else if (backpack_hyps[['my_lambda_target']] == 'dev_ratio'){
          # --- Choose the lambda that best meets your R2-Target
          r2$lambda <- r2$lambda[which(r2$dev.ratio==max(r2$dev.ratio))]
        }
        
        # --- Choose the corresponding betas
        r2$beta <- as.matrix(r2$beta[,which(all_lambdas == r2$lambda)])
        # --- Choose the corresponding alpha
        r2$a0 <- r2$a0[which(all_lambdas == r2$lambda)]
        
      } else {
        
        r2 = glmnet(Y_train, z1+backpack_hyps[['c0']], 
                    intercept = backpack_hyps[['I_want_intercept']], 
                    lambda=backpack_hyps[['my_lambda']], 
                    alpha=backpack_hyps[['my_alpha']], 
                    lower.limits = backpack_hyps[['my_lowerbound']], 
                    type.measure = "mse",
                    standardize=F,
                    standardize.response=F,
                    penalty.factor = ssp,
                    weights = obsw)
        
      }
      
      
      # --- --- Extract the optimal betas ---> needed for adjusting 'z2' in the next step
      if (backpack_hyps[['I_want_cv']]){
        opt_betas <- r2$glmnet.fit$beta[,which(r2$lambda == r2$lambda.min)]
      } else {
        opt_betas <- r2$beta
      }
      
      
      # ----------------------------------------------------------------------------------------------------- #
      #
      #                     Algorithm 1 - Step 6:  Update the LHS
      #
      # ----------------------------------------------------------------------------------------------------- #
      
      
      
      # --- --- Adjust 'z2'
      if (all(opt_betas <= 1e-20)){
        #stop("All weights == 0...nothing to predict...")
        z2new <- rep(0,times=length(z2))
        z2 <- backpack_hyps[['lr']]*z2new + (1-backpack_hyps[['lr']])*z2
      } else {
        if (backpack_hyps[['I_want_cv']]){
          
          z2 <- backpack_hyps[['lr']]*as.vector(scale(predict(r2,newx = Y_train, s=r2$lambda.min))) + (1-backpack_hyps[['lr']])*z2
          
        } else {
          
          z2 <- backpack_hyps[['lr']]*as.vector(scale(predict(r2,newx = Y_train))) + (1-backpack_hyps[['lr']])*z2
          
        }
      }
      
      # ----------------------------------------------------------------------------------------------------- #
      #
      #                     Algorithm 1 - Step 7:  Predictions & Early-Stopping Criteria
      #
      # ----------------------------------------------------------------------------------------------------- #
      
      
      # -------------------------- Predictions: Training-Set  -------------------------- #
      
      # --- --- Y-part
      if (backpack_hyps[['I_want_cv']]){
        pred_y_train <- predict(r2,newx = Y_train, s=r2$lambda.min)
      } else {
        pred_y_train <- c(predict(r2,newx = Y_train))
      }
      
      # --- --- X-part
      pred_x_train <- r1$predictions
      
      
      # --- Add the RMSE of the current iteration
      rmse_train <- sqrt(mean((pred_y_train - pred_x_train)^2)/length(pred_x_train))
      rmse_train_vec <- c(rmse_train_vec,rmse_train)
      
      # --- Check the In-Sample correlation between LHS and RHS
      if (all(opt_betas <= 1e-20)){
        cor_train_vec <- c(cor_train_vec,NA)
      } else {
        cor_train_vec <- c(cor_train_vec,round(cor(pred_y_train,pred_x_train),3))
      }
      
      
      
      
      # -------------------------- Predictions: Test-Set  -------------------------- #
      if (backpack_hyps[['I_want_cv']]){
        pred_y_test <- predict(r2,newx = Y_test, s=r2$lambda.min)
      } else {
        pred_y_test <- predict(r2,newx = Y_test)
      }
      
      # --- --- X-part
      pred_x_test <- predict(r1, data = as.data.frame(cbind(X_test)))$predictions
      
      
      
      
      
      # --- Implement Early-Stopping
      if (backpack_hyps[['I_want_ES']]){
        
        # --- Caution:  Early-Stopping is applied on the Training-Set!
        if (i > backpack_hyps[['ES_patience']]){
          if (any(is.na(rmse_train_vec))){
            print("Training-RMSE is NA! Something's wrong!")
            break
          } else {
            if (all(rmse_train_vec[(i-backpack_hyps[['ES_patience']]+1):i] > rmse_train_vec[i-backpack_hyps[['ES_patience']]])){
              ES_iteartion <- i
              print(paste0("Early-Stopping triggered at Iteration: ", i)) 
              break
            }
          }
        }
        
      }
      
      
      # --- Estimate the Model: Future -> Past
      ols_mod <- lm(LHS ~ RHS, data=data.frame("LHS"=c(pred_y_train),"RHS"=pred_x_train))
      
      # --- Test-R2 Monitor
      pred_test <- predict(ols_mod,newdata=data.frame("LHS"=c(pred_y_test),"RHS"=pred_x_test))
      rsq_test <- r_squared(pred_y_test,pred_test,mean(pred_y_train))
      
      if (rsq_test %in% c(Inf,-Inf)){
        rsq_test_vec <- c(rsq_test_vec,NA)
      } else {
        rsq_test_vec <- c(rsq_test_vec,rsq_test)
      }
      
      # --- Train-R2 Monitor
      rsq_train_vec <- c(rsq_train_vec,summary(ols_mod)$r.squared)
      
      if (F){
        print(paste0("Iteration: ", i, " --- R2 (Training-Set):   ", round(summary(ols_mod)$r.squared,3)))
      }
      
      
      # ----------------------------------------------------------------------------------------------------- #
      #
      #                     Algorithm 1 - Step **:  Collection of Results
      #
      # ----------------------------------------------------------------------------------------------------- #
      
      
      # --- Extract portfolio-weights for next iteration
      if (backpack_hyps[['I_want_cv']]){
        MACE_weights <- r2$glmnet.fit$beta[,which(r2$lambda == r2$lambda.min)] / sum(r2$glmnet.fit$beta[,which(r2$lambda == r2$lambda.min)])
      } else {
        MACE_weights <- as.matrix(r2$beta / sum(r2$beta))
      }
      
      
      # --- Store the models
      r1_hist[[length(r1_hist)+1]] <- r1
      r2_hist[[length(r2_hist)+1]] <- r2
      
      # --- Store the Predictable Future and the Past
      z1_df <- cbind(z1_df,z1)
      colnames(z1_df)[ncol(z1_df)] <- paste0("z1_",i)
      z2_df <- cbind(z2_df,z2)
      colnames(z2_df)[ncol(z2_df)] <- paste0("z2_",i)
      
      
      # ----------------------------------------------------------------------------------------------------- #
      #
      #                     Algorithm 1 - Next Iteration
      #
      # ----------------------------------------------------------------------------------------------------- #
      
      
    }
    
    
    ################################################################################################
    #
    #                    2)       Post-Estimation Evaluation
    #
    ################################################################################################
    
    print(paste0("Estimation for Bag ", bags," done! Post-Estimation Evaluation."))
    
    # --- Step 1: Pick your run!
    my_run <- tail(which(rsq_train_vec == max(rsq_train_vec, na.rm=T)),1)
    
    ts.plot(cbind(rsq_train_vec,rsq_test_vec),col=2:3,lwd=2,
            xlab=expression(bold('Iteration')),ylab=expression(bold('R'^2)))
    legend("bottomright", legend = c('Training-Set','Test-Set'), col = 2:3, lty = 1)
    
    # --- Collect the fits
    r1_hist_Blist[[bags]] <- r1_hist
    r2_hist_Blist[[bags]] <- r2_hist
    my_run_Bvec[bags] <- my_run
    
    
    # ====================================================================================== #
    #                           Make Predictions
    # ====================================================================================== #
    
    # --- Step 1: Get the MACE-Portfolio-Weights
    if (backpack_hyps[['I_want_cv']]){
      MACE_weights <- as.matrix(r2_hist[[my_run]]$glmnet.fit$beta[,which(r2_hist[[my_run]]$lambda == r2_hist[[my_run]]$lambda.min)] / sum(r2_hist[[my_run]]$glmnet.fit$beta[,which(r2_hist[[my_run]]$lambda == r2_hist[[my_run]]$lambda.min)]))
    } else {
      MACE_weights <- as.matrix(r2_hist[[my_run]]$beta / sum(r2_hist[[my_run]]$beta))
    }
    
    
    # --- Step 2: Make Predictions
    if (backpack_hyps[['I_want_cv']]){
      hy_test <- as.vector(predict(r2_hist[[my_run]], newx = Y_test, s=r2_hist[[my_run]]$lambda.min))
      hy_train <- as.vector(predict(r2_hist[[my_run]], newx = Y_train, s=r2_hist[[my_run]]$lambda.min))
    } else {
      hy_test <- as.vector(predict(r2_hist[[my_run]], newx = Y_test))
      hy_train <- as.vector(predict(r2_hist[[my_run]], newx = Y_train))
    }
    
    
    
    hx_train <- r1_hist[[my_run]]$predictions
    hx_test <- predict(r1_hist[[my_run]], data = as.data.frame(cbind(X_test)))$predictions
    
    # -------------------------- Get the PREDICTIONS for MACE's OOS-return  -------------------------------- #
    ols_mod <- lm(LHS ~ RHS, data=data.frame("LHS"=hy_train,"RHS"=hx_train))
    
    fit_train <- ols_mod$fitted.values
    fit_test <- predict(ols_mod, newdata=data.frame("LHS"=hy_test,"RHS"=hx_test))
    
    
    if (backpack_hyps[['I_want_cv']]){
      pick_cv <- which(r2_hist[[my_run]]$lambda == r2_hist[[my_run]]$lambda.min)
      
      MACE_pred_train <- (fit_train-r2_hist[[my_run]]$glmnet.fit$a0[pick_cv])/sum(as.vector(r2_hist[[my_run]]$glmnet.fit$beta[,pick_cv]))
      MACE_pred_test <- (fit_test-r2_hist[[my_run]]$glmnet.fit$a0[pick_cv])/sum(as.vector(r2_hist[[my_run]]$glmnet.fit$beta[,pick_cv]))
    } else {
      
      MACE_pred_train <- (fit_train-r2_hist[[my_run]]$a0)/sum(as.vector(r2_hist[[my_run]]$beta))
      MACE_pred_test <- (fit_test-r2_hist[[my_run]]$a0)/sum(as.vector(r2_hist[[my_run]]$beta))
    }
    
    
    # --- Collect the Predictions
    hx_train_Bdf[,paste0("B",bags)] <- hx_train
    hx_test_Bdf[,paste0("B",bags)] <- hx_test
    hy_train_Bdf[,paste0("B",bags)] <- hy_train
    hy_test_Bdf[,paste0("B",bags)] <- hy_test
    fit_train_Bdf[,paste0("B",bags)] <- fit_train
    fit_test_Bdf[,paste0("B",bags)] <- fit_test
    
    # --- Collect the R2
    R2_train_Bvec[bags] <- r_squared(hy_train,fit_train,mean(hy_train))
    R2_test_Bvec[bags] <- r_squared(hy_test,fit_test,mean(hy_train))
    
    
    print(paste0("Bag: ", bags, " --- R2 (Training-Set):         ", round(R2_train_Bvec[bags],3)))
    print(paste0("Bag: ", bags, " --- R2 (Test-Set):             ", round(R2_test_Bvec[bags],3)))
    
    
    ################################################################################################
    #
    #                    3)       Store the Bag's Output
    #
    ################################################################################################
    
    
    # --- Some metrics:
    rmse_train_Bdf[,bags] <- c(rmse_train_vec, rep(NA,times=backpack_hyps[['maxit']]-length(rmse_train_vec)))
    rsq_train_Bdf[,bags] <- c(rsq_train_vec, rep(NA,times=backpack_hyps[['maxit']]-length(rsq_train_vec)))
    rsq_test_Bdf[,bags] <- c(rsq_test_vec, rep(NA,times=backpack_hyps[['maxit']]-length(rsq_test_vec)))
    
    
    
    # --- Storage for Predictions
    df_pred_Blist$Train$MACE[,paste0("B",bags)] <- MACE_pred_train
    df_pred_Blist$Test$MACE[,paste0("B",bags)] <- MACE_pred_test
    
    
    # --- Storage for portfolio-weights
    for (aa in rownames(MACE_weights)){
      df_MACE_weights_Bdf[bags,which(colnames(df_MACE_weights_Bdf) == aa)] <- as.numeric(MACE_weights[aa,1])
    }
    
    # --- Next 'bags'
  }
  
  
  # --- Pack the output
  backpack_out <- list('rsq_train_Bdf'=rsq_train_Bdf,
                       'rsq_test_Bdf'=rsq_test_Bdf,
                       'hx_train_Bdf'=hx_train_Bdf,
                       'hx_test_Bdf'=hx_test_Bdf,
                       'hy_train_Bdf'=hy_train_Bdf,
                       'hy_test_Bdf'=hy_test_Bdf,
                       'fit_train_Bdf'=fit_train_Bdf,
                       'fit_test_Bdf'=fit_test_Bdf,
                       'my_run_Bvec'=my_run_Bvec,
                       'R2_train_Bvec'=R2_train_Bvec,
                       'R2_test_Bvec'=R2_test_Bvec,
                       'r1_hist_Blist'=r1_hist_Blist,
                       'r2_hist_Blist'=r2_hist_Blist,
                       'df_MACE_weights_Bdf'=df_MACE_weights_Bdf,
                       'df_pred_Blist'=df_pred_Blist)
  
  
  
  return(backpack_out)
  
}