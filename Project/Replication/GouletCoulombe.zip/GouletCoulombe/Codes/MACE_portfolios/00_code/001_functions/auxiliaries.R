r_squared <- function(y_true, y_pred, y_ins){
  
  SSR <- sum((y_true - y_pred)^2)
  SST <- sum((y_true - y_ins)^2)  
  
  return(1 - SSR/SST)
}

# ================================================================================================================ #


annualized_total_return <- function(series,freq){
  # --- freq: in terms of annual observations (i.e. monthly = 1/12; quarterly = 1/4; yearly=1)
  return(prod(1+series)^(1/(length(series)*freq))-1)
}

# ================================================================================================================ #


annualized_total_vola <- function(series,freq){
  # --- freq: in terms of annual observations (i.e. monthly = 1/12; quarterly = 1/4; yearly=1)
  return(sd(series)* sqrt(1/freq))
}

# ================================================================================================================ #

annualized_return <- function(series,freq){
  # --- freq: in terms of annual observations (i.e. monthly = 1/12; quarterly = 1/4; yearly=1)
  return(mean(series)*(1/freq))
}

# ================================================================================================================ #


annualized_vola <- function(series,freq){
  # --- freq: in terms of annual observations (i.e. monthly = 1/12; quarterly = 1/4; yearly=1)
  return(sd(series*(1/freq))* (1/sqrt(1/freq)))
}

# ================================================================================================================ #


sharpe_ratio <- function(series,freq){
  # --- freq: in terms of annual observations (i.e. monthly = 1/12; quarterly = 1/4; yearly=1)
  return(annualized_return(series,freq)/annualized_vola(series,freq))
}

# ================================================================================================================ #


series_transform <- function(series,my_trans,h){
  if (my_trans == 'direct'){ # ---> no transformation necessary
    return(series)
  } else if (my_trans == 'MA'){ # ---> transform your desired series (mostly the MoM-SP500 Return) into
    #       h-period Moving-Averages
    # --- Calculate the cumulative return
    cum_cc <- c(0,cumsum(series))
    N <- length(cum_cc)
    
    # --- Calculate the h-month Moving-Average Return
    return( c(rep(NA,times=h-1),(cum_cc[(h+1):N] - cum_cc[1:(N-h)]) / h ))
    #return( c((cum_cc[(h+1):N] - cum_cc[1:(N-h)]) / h,rep(NA,times=h-1) )) ---> for version v221219
    
  } else if (my_trans == 'ContComp'){ # ---> transform your desired series (mostly the MoM-SP500 Return) into
    #       h-period Moving-Averages
    # --- Calculate the cumulative return
    cum_cc <- c(0,cumsum(series))
    N <- length(cum_cc)
    
    # --- Calculate the h-month Moving-Average Return
    return( c(rep(NA,times=h-1),(cum_cc[(h+1):N] - cum_cc[1:(N-h)]) ))
    #return( c((cum_cc[(h+1):N] - cum_cc[1:(N-h)]) / h,rep(NA,times=h-1) )) ---> for version v221219
    
  }
}


# ================================================================================================================ #


ewma <- function(x, lambda) {
  
  # --- If x is a vector
  if (is.null(dim(x))){
    # x = vector of returns
    if (length(x) <= 1 || !all(!is.na(x)) || !is.numeric(x)) {
      stop("A numeric vector of length > 1 and without NAs must be passed to",
           " 'x'.")
    }
    if (length(lambda) != 1 || is.na(lambda) || !is.numeric(lambda) ||
        lambda < 0 || lambda >= 1) {
      stop("The argument 'lambda' must be a single non-NA double value with ",
           "0 < lambda < 1.")
    }
    n <- length(x)
    vol <- rep(NA, n)
    vol[1] <- stats::var(x)
    for (i in 2:n) {
      vol[i] <- lambda * vol[i - 1] + (1 - lambda) * x[i - 1]^2
    }
  
  } else {
    
    n <- nrow(x)
    vol <- rep(list(c()), n)
    vol[[1]] <- stats::cov(x)
    for (i in 2:n) {
      ret_i <- x[(i - 1),]
      vol[[i]] <- lambda * vol[[i - 1]] + (1 - lambda) * (ret_i %*% t(ret_i))
    }
    
  }  
    
  return(vol)
}

# ================================================================================================================ #


drawdown <- function(series){
  
  # series:   plain returns
  TT <- length(series)
  DD <- c()
  
  for (tt in 1:TT){
    DD <- c(DD,log(cumprod(1+series)[tt]) - log(cumprod(1+series)[tt:TT]))
  }
  
  return(DD)
}

# ================================================================================================================ #

func_turnoverGKX <- function(series,weights){
  
  if (class(series)[1] %in% c('matrix','data.frame')){
    TT <- nrow(weights)
    turnover <- c()
  
    for (tt in 2:TT){
      weights_previous_tt <- weights[tt-1,]*series[tt,]
      turnover <- c(turnover,sum(abs(weights[tt,] - (weights[tt-1,]*(1+series[tt,]) / (1 + (sum(weights_previous_tt, na.rm=T) - weights[tt-1,]*series[tt,])) )),na.rm=T))
    }
  } else {
    TT <- length(weights)
    turnover <- c()
    
    for (tt in 2:TT){
      weights_previous_tt <- weights[tt-1]*series[tt]
      turnover <- c(turnover,abs(weights[tt] - (weights[tt-1]*(1+series[tt]) / (1 + (sum(weights_previous_tt, na.rm=T) - weights[tt-1]*series[tt])) )))
    }
  }
  
  return(sum(turnover, na.rm=T) / TT)
}


# ================================================================================================================ #

func_turnoverCG20 <- function(series,weights){
  
  TT <- nrow(weights)
  turnover <- c()
  
  for (tt in 2:TT){
    weights_previous_tt <- weights[tt-1,]*(1+series[tt,])
    turnover <- c(turnover,apply(abs(weights[tt,] - weights_previous_tt/sum(weights_previous_tt,na.rm=T)),1,sum,na.rm=T))
  }
  
  return(sum(turnover, na.rm=T) / (TT-1))
}

# ================================================================================================================ #


roll_mean <- function(series_oos,series_ins,lookback,h){
  roll_mean_store <- c()
  if (length(series_oos) == 0){
    for (ll in 1){
      if (h > ll){
        roll_mean_store <- c(roll_mean_store,mean(tail(c(series_ins[0:(length(series_ins)-h)]),lookback)))
      } else {
        roll_mean_store <- c(roll_mean_store,mean(tail(c(series_ins,series_oos[0:(ll-h)]),lookback)))
      }
    }
  } else {
    for (ll in 1:length(series_oos)){
      if (h > ll){
        roll_mean_store <- c(roll_mean_store,mean(tail(c(series_ins[0:(length(series_ins)-h)]),lookback)))
      } else {
        roll_mean_store <- c(roll_mean_store,mean(tail(c(series_ins,series_oos[0:(ll-h)]),lookback)))
      }
    }
  }
  
  return(roll_mean_store)
}

# ================================================================================================================ #


MeanVariance <- function(return_oos_true,return_oos_pred,return_ins,params){
  
  # --- Unpack your parameters
  lookback <- params[["lookback"]]
  gamma_mv <- params[["gamma"]]
  alpha_mv <- params[["alpha"]]
  port_pos_max <- params[["MV_pos_max"]]
  port_pos_min <- params[["MV_pos_min"]]
  
  position_oos <- rep(0,times=length(return_oos_pred))
  
  for (tt in 1:length(return_oos_pred)){
    # --- Prediction for period 'tt'
    return_pred_tt <- return_oos_pred[tt]
    # --- Calculate the Exponentially-Weighted-Moving-Average of the variance of the portfolio
    sigma2_tt <- tail(ewma(tail(c(return_ins,return_oos_true[0:(tt-1)]),lookback), alpha_mv),1) 
    # --- Calculate the optimal weight
    weight_tt <- (1/gamma_mv)*(return_pred_tt/sigma2_tt)
    # --- Keep the weight within reasonable bounds
    position_oos[tt] <- max(c(min(weight_tt,port_pos_max),port_pos_min))
  }
  
  # --- Calculate returns & store positions
  out <- list('position'=position_oos, 'return'=position_oos * return_oos_true)
  
  return(out)
  
  
}

# ================================================================================================================ #


MinVarWeights <- function(stock_returns,params,I_want_MinVar=T){
  
  library(quadprog)
  library(Matrix)
  
  
  if (I_want_MinVar){
    # --- --- Get the mean returns -- for minimum-variance
    SS_return_mean <- rep(0,times=dim(stock_returns)[2])
  } else {
    # --- --- Get the mean returns -- for mean-variance
    SS_return_mean <- apply(stock_returns,2,mean)
  }
    
  
  
  # --- --- Get the Variance-Covariance Matrix
  # --- --- --- EWMA? Or Sample-Covariance-Matrix?
  if (params[["I_want_ewma"]]){
    SS_return_cov <- tail(ewma(x=stock_returns,lambda = params[["alpha"]]),1)[[1]]
  } else {
    SS_return_cov <- cov(stock_returns)
  }
  
  
  # --- --- Add constraints ---> First state all Equality-Constraints, THEN all Inequality constraints (>=)
  if (params[["shortselling"]]){
    A_transpose <- rbind(
      # --- All weights sum to 1
      c(rep(1,times=ncol(stock_returns)))
    )
    b_vec <- c(
      # --- All weights sum to 1
      1
    )
  } else {
    A_transpose <- rbind(
      # --- All weights sum to 1
      c(rep(1,times=ncol(stock_returns))),
      # --- Each weight is larger than 0
      diag(x=rep(1,times=ncol(stock_returns)))
    )
    b_vec <- c(
      # --- All weights sum to 1
      1,
      # --- Each weight is larger than 0
      rep(0,times=ncol(stock_returns))
    )
  }
  
  # --- Check whether 'SS_return_cov' is positive-definite
  cov_eigen <- eigen(SS_return_cov)
  if (any(cov_eigen$values < 1e-10)){
    SS_return_cov <- as.matrix(nearPD(x=SS_return_cov,keepDiag = TRUE)$mat)
  }
  
  # --- Let the solver work
  solver_out <- solve.QP(Dmat = 2*SS_return_cov, dvec = SS_return_mean,
                         Amat = t(A_transpose), bvec = b_vec, meq = 1) 
  
  # --- Extract the Portfolio Weights
  MP_weights <- solver_out$solution
  
  out <- list("stocks_return_mean"=SS_return_mean,"stocks_return_cov"=SS_return_cov,"weights"=MP_weights)
  
  return(out)
  
}


# ================================================================================================================ #

block.sampler <- function(X,sampling_rate,block_size,num.tree){
  
  inbag=list()
  inbag2=list()
  
  for(j in 1:num.tree){
    sample_index <- c(1:nrow(X))
    groups<-sort(base::sample(x=c(1:(length(sample_index)/block_size)),size=length(sample_index),replace=TRUE))
    rando.vec <- rexp(rate=1,n=length(sample_index)/block_size)[groups] +0.1
    chosen.ones.plus<-rando.vec
    rando.vec<-which(chosen.ones.plus>quantile(chosen.ones.plus,1-sampling_rate))
    chosen.ones.plus<-sample_index[rando.vec]
    
    boot <- c(sort(chosen.ones.plus))                         
    oob <- c(1:nrow(X))[-boot]   
    count = 1:nrow(X)
    inbagj = I(is.element(count,boot))
    inbag[[j]] = as.numeric(inbagj)
  }
  
  for(j in 1:num.tree){
    sample_index <- c(1:nrow(X))
    groups<-sort(base::sample(x=c(1:(length(sample_index)/block_size)),size=length(sample_index),replace=TRUE))
    rando.vec <- rexp(rate=1,n=length(sample_index)/block_size)[groups] +0.1
    chosen.ones.plus<-rando.vec
    rando.vec<-which(chosen.ones.plus>quantile(chosen.ones.plus,1-sampling_rate))
    chosen.ones.plus<-sample_index[rando.vec]
    
    boot <- c(sort(chosen.ones.plus))                         
    oob <- c(1:nrow(X))[-boot]   
    count = 1:nrow(X)
    inbagj = I(is.element(count,boot))
    inbag2[[j]] = as.numeric(inbagj)
  }
  
  return(list(inbag1=inbag,inbag2=inbag2))
}

# ================================================================================================================ #

scatter_plot <- function(x,y,label_x,label_y="Shapley Values"){
  data <- data.frame(cbind(x=x,y=y))
  ggplot(data,aes(x=x,y=y)) + geom_point() + geom_smooth(method = loess,se=F,fullrange=T) + 
    xlab(label_x) + ylab(label_y) + theme_bw()
}

# ================================================================================================================ #

pred_max <- function(object,newdata){
  predict(object,data=newdata)$predictions 
}

# ================================================================================================================ #

theme_Publication <- function(base_size=30, base_family="Arial") {
  library(grid)
  library(ggthemes)
  library(ggthemes)
  library(DescTools)
  (theme_foundation(base_size=base_size, base_family=base_family)
    + theme(plot.title = element_text(face = "bold",
                                      size = rel(1.3), hjust = 0.5),
            text = element_text(),
            panel.background = element_rect(colour = NA),
            plot.background = element_rect(colour = NA),
            panel.border = element_rect(colour = 'black'),
            axis.title = element_text(face = "bold",size = rel(1)),
            axis.title.y = element_text(angle=90,vjust =2),
            axis.title.x = element_text(angle=45,vjust = -0.2),
            axis.text = element_text(),
            axis.line = element_line(colour="black"),
            axis.ticks = element_line(),
            panel.grid.major = element_line(colour="#f0f0f0"),
            panel.grid.minor = element_blank(),
            legend.key = element_rect(colour = NA),
            legend.position = "bottom",
            legend.direction = "horizontal",
            legend.key.size= unit(0.6, "cm"),
            #legend.margin = unit(0, "cm"),
            legend.margin=margin(-20,5,5,-20),
            legend.box.margin=margin(-5,-5,-5,-5),
            #legend.text=element_text(size=12),
            legend.title = element_text(face="italic"),
            #plot.margin=unit(c(5,5,5,5),"mm"),
            strip.background=element_rect(colour="#f0f0f0",fill="#f0f0f0"),
            strip.text = element_text(face="bold")
    ))
  
}


break_function = function(x) {
  # if(x[2]*x[1]<0){ #gotta include zero
  
  #target=7
  #for(i in 3:20){
  i=6
  init = seq(from = x[1], to = x[2], length.out = i)
  ll = abs(init[2]-init[1])
  candi = c(0.005,0.01,0.05,0.1,0.2,0.25,0.5,1,2,2.5,5,10)
  gapchoice=candi[which.min(abs(ll-candi))]
  xnew = RoundTo(x,gapchoice)
  if(xnew[1]>x[1]){xnew[1]-gapchoice}
  if(xnew[2]<x[2]){xnew[2]+gapchoice}
  thisshit=seq(from = xnew[1], to = xnew[2], by = gapchoice)
  #if(length(thisshit)==target){finalshit=thisshit}
  #print(length(thisshit))
  #}
  # }
  #unique(RoundTo(sort(append(0,)),multiple=0.05))
  return(thisshit)
}


# ================================================================================================================ #

nber <- function(start_year,end_year,freq){
  
  library(quantmod)
  library(lubridate)
  
  # --- Download Recession-dates from FRED
  raw <- data.frame(getSymbols('USREC', src = 'FRED', auto.assign = F))
  NBER_Rec <- data.frame("DATE"=rownames(raw),"USREC"=raw$USREC)
  
  NBER_df <- data.frame(matrix(NA, nrow = (end_year-start_year + 1)*12, ncol = 3))
  
  years <- seq(start_year,end_year,1)
  years_repeated <- 0
  for (repeate in 1:length(years)){
    years_repeated[(length(years_repeated)+1):(length(years_repeated)+12)] <- rep(years[repeate], times = 12)
  }
  years_repeated <- years_repeated[-1]
  
  NBER_df[,1] <- years_repeated
  NBER_df[,2] <- rep(seq(1,12,1), times=length(years))
  #----assigning S&P and ConSent
  NBER_df[,3] <- NBER_Rec[which(NBER_Rec[,1]==paste0(start_year,"-01-01")):which(NBER_Rec[,1]==paste0(end_year,"-12-01")), 2]
  NBER_df[,4] = seq(start_year + (1-1)/12, end_year + (12-1)/12, by = 1/12)
  colnames(NBER_df) <- c("Year", "Month", "NBER_Rec", "Date")
  
  #create start-end data frame for NBER
  NBER_dates <- data.frame(matrix(NA,1,2))
  colnames(NBER_dates) <- c("start", "end")
  
  # --- Define START- and END-Dates
  rec_months <- which(NBER_df$NBER_Rec == 1)
  
  if (length(rec_months) > 0){
    NBER_dates[dim(NBER_dates)[1]+1,1] <- NBER_df$Date[rec_months[1]]
    for (rr in 2:length(rec_months)){
      
      if (rec_months[rr] == rec_months[rr-1] + 1){
        
        # --- At the end of the loop, set the end date as follows:
        if (rr == length(rec_months)){
          NBER_dates[dim(NBER_dates)[1],2] <- NBER_df$Date[rec_months[rr]]
        }
        
      } else {
        # --- Set the end of the PREVIOUS Recession
        NBER_dates[dim(NBER_dates)[1],2] <- NBER_df$Date[rec_months[rr-1]]
        # --- Set the start of the NEW Recession
        NBER_dates[dim(NBER_dates)[1]+1,1] <- NBER_df$Date[rec_months[rr]]
        
        # --- At the end of the loop, set the end date as follows:
        if (rr == length(rec_months)){
          NBER_dates[dim(NBER_dates)[1],2] <- NBER_df$Date[rec_months[rr]]
        }
        
      }
      
    }
    
    # --- The old and not entirely bug-free procedure of defining START- and END-Dates
    #     (The algorithm couldn't work with some end-dates and would break)
    if (1==2){
      counter <- 1
      for (nber in counter:(dim(NBER_df)[1]-1)){
        nber <- counter
        if ((NBER_df$NBER_Rec[nber] == 1)==TRUE){
          NBER_dates[dim(NBER_dates)[1]+1,1] <- NBER_df$Date[nber]
          new_row <- min(which(NBER_df$NBER_Rec[(nber+1):dim(NBER_df)[1]] < 1)) + nber
          NBER_dates[dim(NBER_dates)[1],2] <- NBER_df$Date[(new_row-1)]
          counter <- new_row
        } else if (counter < dim(NBER_df)[1]) {
          counter <- counter + 1
        }
      }
    }
    NBER_dates <- NBER_dates[-1,]
    NBER_dates <- data.frame(start = c(NBER_dates$start), end = c(NBER_dates$end))
    
    if (freq %in% c(1,4)){
      #   Transform into Quarters
      NBER_dates_Q <- NBER_dates
      for (r in 1:nrow(NBER_dates)){
        for (c in 1:ncol(NBER_dates)){
          if (NBER_dates[r,c] - as.numeric(substr(NBER_dates[r,c],start=1,stop=4)) < 0.25){
            NBER_dates_Q[r,c] <- as.numeric(paste0(substr(NBER_dates[r,c],start=1,stop=4),".00"))
          } else if (NBER_dates[r,c] - as.numeric(substr(NBER_dates[r,c],start=1,stop=4)) >= 0.25 && (NBER_dates[r,c] - as.numeric(substr(NBER_dates[r,c],start=1,stop=4)) < 0.5)){
            NBER_dates_Q[r,c] <- as.numeric(paste0(substr(NBER_dates[r,c],start=1,stop=4),".25"))
          } else if (NBER_dates[r,c] - as.numeric(substr(NBER_dates[r,c],start=1,stop=4)) >= 0.5 && (NBER_dates[r,c] - as.numeric(substr(NBER_dates[r,c],start=1,stop=4)) < 0.75)){
            NBER_dates_Q[r,c] <- as.numeric(paste0(substr(NBER_dates[r,c],start=1,stop=4),".50"))
          } else if (NBER_dates[r,c] - as.numeric(substr(NBER_dates[r,c],start=1,stop=4)) >= 0.75){
            NBER_dates_Q[r,c] <- as.numeric(paste0(substr(NBER_dates[r,c],start=1,stop=4),".75"))
          }
        }
      }
      NBER_dates <- NBER_dates_Q
    }
  } else {
    NBER_dates <- data.frame()
  }
  return(NBER_dates)
  
}