MACE_VI <- function(backpack_data,backpack_VI){
  
  
  # --- Unpack some of the parameters:
  MACE_out <- backpack_VI[['MACE_out']]
  bag <- backpack_VI[['bag']]

  # --- Out-of-Sample Period:
  oos_period <- backpack_data[['time']][(length(backpack_data[['time']])-nrow(backpack_data[['Y_test']])+1):length(backpack_data[['time']])]
  
  
  
  # ----------------------------- Shapley-Value Computation: In-Sample ------------------------------------ #
  print('Computing Shapley-Values In-Sample for MACE...')
  MACE_shap_ins_local <- explain(MACE_out[['r1_hist_Blist']][[bag]][[MACE_out[['my_run_Bvec']][[bag]]]],
                                 X=backpack_data[['X_train']],nsim=10,adjust=TRUE,pred_wrapper=pred_max)
  
  if (backpack_VI[['I_want_EW']]){
    print('Computing Shapley-Values In-Sample for Equally-Weighted Portfolio...')
    EW_shap_ins_local <- explain(backpack_VI[['EW_ranger']],X=backpack_data[['X_train']],
                                 nsim=10,adjust=TRUE,pred_wrapper=pred_max)
  }
  
  
  
  # ----------------------------- Shapley-Value Computation: Out-Of-Sample ------------------------------------ #
  print('Computing Shapley-Values Out-of-Sample for MACE...')
  MACE_shap_oos_local <- explain(MACE_out[['r1_hist_Blist']][[bag]][[MACE_out[['my_run_Bvec']][[bag]]]],
                                 X=backpack_data[['X_test']],nsim=10,adjust=TRUE,pred_wrapper=pred_max)
  
  if (backpack_VI[['I_want_EW']]){
    print('Computing Shapley-Values Out-of-Sample for Equally-Weighted Portfolio...')
    EW_shap_oos_local <- explain(backpack_VI[['EW_ranger']],X=backpack_data[['X_test']],
                                 nsim=10,adjust=TRUE,pred_wrapper=pred_max)
  } 
  
  print('Shapley-Values done. On to plotting...')
  
  # ----------------------------- GLOBAL Shapley-Values: In-Sample ------------------------------------ #
  MACE_shap_ins_global_abs <- sort(apply(abs(MACE_shap_ins_local),2,sum), decreasing = T)
  EW_shap_ins_global_abs <- sort(apply(abs(EW_shap_ins_local),2,sum), decreasing = T)
  
  # ----------------------------- GLOBAL Shapley-Values: Out-Of-Sample ------------------------------------ #
  MACE_shap_oos_global_abs <- sort(apply(abs(MACE_shap_oos_local),2,sum), decreasing = T)
  EW_shap_oos_global_abs <- sort(apply(abs(EW_shap_oos_local),2,sum), decreasing = T)
  
  
  # ----------------------------- GROUPED Shapley-Values: GLOBAL + LOCAL -------------------------- #
  #
  #       ---> Shapley-Values are aggregated across lags of a given predictor
  
  
  # --- MACE
  grouped_vars <- gsub("L1_","",colnames(MACE_shap_oos_local)[grepl("L1_",colnames(MACE_shap_oos_local))])
  grouped_vars <- gsub("FD_","",grouped_vars)
  
  MACE_groupshap_oos_global <- setNames(rep(NA,times=length(grouped_vars)),grouped_vars)
  MACE_groupshap_ins_global <- setNames(rep(NA,times=length(grouped_vars)),grouped_vars)
  MACE_groupshap_oos_local <- data.frame(matrix(NA,nrow=nrow(MACE_shap_oos_local),
                                                ncol=length(grouped_vars),
                                                dimnames=list(c(),grouped_vars)))
  MACE_groupshap_ins_local <- data.frame(matrix(NA,nrow=nrow(MACE_shap_ins_local),
                                                ncol=length(grouped_vars),
                                                dimnames=list(c(),grouped_vars)))
  for (gg in grouped_vars){
    # --- Out-Of-Sample
    col_idx <- grep(gg,names(MACE_shap_oos_local))
    MACE_groupshap_oos_global[gg] <- sum(apply(MACE_shap_oos_local[,col_idx],2,sum))
    MACE_groupshap_oos_local[,gg] <- apply(MACE_shap_oos_local[,col_idx],1,sum)
    # --- In-Sample
    col_idx <- grep(gg,names(MACE_shap_ins_local))
    MACE_groupshap_ins_global[gg] <- sum(apply(MACE_shap_ins_local[,col_idx],2,sum))
    MACE_groupshap_ins_local[,gg] <- apply(MACE_shap_ins_local[,col_idx],1,sum)
  }
  MACE_groupshap_oos_global_abs <- sort(abs(MACE_groupshap_oos_global),decreasing=T)
  MACE_groupshap_ins_global_abs <- sort(abs(MACE_groupshap_ins_global),decreasing=T)
  
  if (backpack_VI[['I_want_EW']]){
    grouped_vars <- gsub("L1_","",colnames(EW_shap_oos_local)[grepl("L1_",colnames(EW_shap_oos_local))])
    grouped_vars <- gsub("FD_","",grouped_vars)
    
    EW_groupshap_oos_global <- setNames(rep(NA,times=length(grouped_vars)),grouped_vars)
    EW_groupshap_ins_global <- setNames(rep(NA,times=length(grouped_vars)),grouped_vars)
    for (gg in grouped_vars){
      # --- Out-Of-Sample
      col_idx <- grep(gg,names(EW_shap_oos_local))
      EW_groupshap_oos_global[gg] <- sum(apply(EW_shap_oos_local[,col_idx],2,sum))
      # --- In-Sample
      col_idx <- grep(gg,names(EW_shap_ins_local))
      EW_groupshap_ins_global[gg] <- sum(apply(EW_shap_ins_local[,col_idx],2,sum))
    }
    EW_groupshap_oos_global_abs <- sort(abs(EW_groupshap_oos_global),decreasing=T)
    EW_groupshap_ins_global_abs <- sort(abs(EW_groupshap_ins_global),decreasing=T)
  }
  
  
  # ---------------------------------------------------------------------------------------------- #
  #
  #                               Horizontal Barplots (Figure 7)
  #
  # ---------------------------------------------------------------------------------------------- #
  
  
  # ----------------------------- Plot: SINGLE Shapley-Values: In-Sample -------------------------- #
  
  # --- MACE
  plot_df <- data.frame(matrix(data = NA, ncol = 3, nrow = 5)) #25 most important features
  plot_df[,1] <- gsub("FD_","",names(MACE_shap_ins_global_abs)[1:5])   #variable names
  plot_df[,2] <- as.numeric(MACE_shap_ins_global_abs / max(MACE_shap_ins_global_abs))[1:5] #VI values
  plot_df[,3] <- c(c("A"),rep(c("B","A"),2)) #color codes for alternating red and blue for 25 bars
  
  
  p <- ggplot(data=plot_df, aes(x=X2, y=reorder(X1, X2), fill = X3)) +
    geom_bar(stat="identity", orientation = "y", color = 'black')+
    scale_x_continuous(expand = c(0, 0), limits = c(0, max(plot_df$X2)+0.01),breaks = scales::pretty_breaks(n = 8))+
    theme(legend.position="none",axis.text=element_text(size=16)) +
    xlab("")+
    ylab("")+ 
    theme(strip.text = element_text(face="bold", size=16)) +
    theme_Publication() +
    theme(strip.text = element_text(face="bold", size=16))+
    theme(legend.text=element_text(size=16),legend.key.size = unit(3,"line"),legend.margin=margin(-10,25,25,-10),
          legend.box.margin=margin(-20,-20,-20,-20), #axis.text.x = element_blank(),
          strip.text = element_text(face="bold", colour = "white",size=16,family="Helvetica"), 
          legend.title=element_blank(),axis.text.x = element_text(face = c('plain', 'plain', 'plain', 'plain', 'plain')),
          strip.background=element_rect(colour="black",fill="black"),
          plot.margin = grid::unit(c(5,5,5,-11), "mm"))+
    xlab('') +scale_fill_manual("legend", values = c("A" ="#ef3b2c", "B" = "#386cb0"))+ theme(legend.position="none")
  p 
  if (1==1){
    ggsave(file=file.path(backpack_VI[['directory_figures']],"VI_InSample_MACE.png"),
           plot = p, dpi=150, dev='png', height=250, width=300, units="mm",scale = 1.1)
  }
  
  
  if (backpack_VI[['I_want_EW']]){
    
    # --- Equally-Weighted Portfolio
    plot_df <- data.frame(matrix(data = NA, ncol = 3, nrow = 5)) #25 most important features
    plot_df[,1] <- gsub("FD_","",names(EW_shap_ins_global_abs)[1:5])   #variable names
    plot_df[,2] <- as.numeric(EW_shap_ins_global_abs / max(EW_shap_ins_global_abs))[1:5] #VI values
    plot_df[,3] <- c(c("A"),rep(c("B","A"),2)) #color codes for alternating red and blue for 25 bars
    
    
    p <- ggplot(data=plot_df, aes(x=X2, y=reorder(X1, X2), fill = X3)) +
      geom_bar(stat="identity", orientation = "y", color = 'black')+
      scale_x_continuous(expand = c(0, 0), limits = c(0, max(plot_df$X2)+0.01),breaks = scales::pretty_breaks(n = 8))+
      theme(legend.position="none",axis.text=element_text(size=16)) +
      xlab("")+
      ylab("")+ 
      theme(strip.text = element_text(face="bold", size=16)) +
      theme_Publication() +
      theme(strip.text = element_text(face="bold", size=16))+
      theme(legend.text=element_text(size=16),legend.key.size = unit(3,"line"),legend.margin=margin(-10,25,25,-10),
            legend.box.margin=margin(-20,-20,-20,-20), #axis.text.x = element_blank(),
            strip.text = element_text(face="bold", colour = "white",size=16,family="Helvetica"), 
            legend.title=element_blank(),axis.text.x = element_text(face = c('plain', 'plain', 'plain', 'plain', 'plain')),
            strip.background=element_rect(colour="black",fill="black"),
            plot.margin = grid::unit(c(5,5,5,-11), "mm"))+
      xlab('') +scale_fill_manual("legend", values = c("A" ="#ef3b2c", "B" = "#386cb0"))+ theme(legend.position="none")
    p 
    if (1==1){
      ggsave(file=file.path(backpack_VI[['directory_figures']],"VI_InSample_EW.png"),
             plot = p, dpi=150, dev='png', height=250, width=300, units="mm",scale = 1.1)
    }
    
    
  }
  
  
  # ----------------------------- Plot: SINGLE Shapley-Values: Out-Of-Sample -------------------------- #
  
  # --- MACE
  plot_df <- data.frame(matrix(data = NA, ncol = 3, nrow = 5)) #25 most important features
  plot_df[,1] <- gsub("FD_","",names(MACE_shap_oos_global_abs)[1:5])   #variable names
  plot_df[,2] <- as.numeric(MACE_shap_oos_global_abs / max(MACE_shap_oos_global_abs))[1:5] #VI values
  plot_df[,3] <- c(c("A"),rep(c("B","A"),2)) #color codes for alternating red and blue for 25 bars
  
  
  p <- ggplot(data=plot_df, aes(x=X2, y=reorder(X1, X2), fill = X3)) +
    geom_bar(stat="identity", orientation = "y", color = 'black')+
    scale_x_continuous(expand = c(0, 0), limits = c(0, max(plot_df$X2)+0.01),
                       breaks = scales::pretty_breaks(n = 5))+
    theme_Publication() +
    theme(legend.text=element_text(size=16),legend.key.size = unit(3,"line"),legend.margin=margin(-10,25,25,-10),
          legend.box.margin=margin(-20,-20,-20,-20), #
          axis.text = element_text( size=30,family="Helvetica"),
          strip.text = element_text(face="bold", colour = "white",size=25,family="Helvetica"), 
          legend.title=element_blank(),axis.text.x = element_text(face = c('plain')),
          strip.background=element_rect(colour="black",fill="black"),
          plot.margin = grid::unit(c(5,5,5,-11), "mm")
          #aspect.ratio = 1/2
    )+
    xlab('') + ylab("") + scale_fill_manual("legend", values = c("A" ="#ef3b2c", "B" = "#386cb0"))+ 
    theme(legend.position="none")
  p 
  if (1==1){
    ggsave(file.path(backpack_VI[['directory_figures']],"VI_OOS_MACE.png"),
           plot = p, dpi=150, dev='png', 
           #height=250, width=300, 
           height=150, width=250, 
           units="mm",scale = 1)
  }
  
  
  
  if (backpack_VI[['I_want_EW']]){
    
    # --- Equally-Weighted Portfolio
    plot_df <- data.frame(matrix(data = NA, ncol = 3, nrow = 5)) #25 most important features
    plot_df[,1] <- gsub("FD_","",names(EW_shap_oos_global_abs)[1:5])   #variable names
    plot_df[,2] <- as.numeric(EW_shap_oos_global_abs / max(EW_shap_oos_global_abs))[1:5] #VI values
    plot_df[,3] <- c(c("A"),rep(c("B","A"),2)) #color codes for alternating red and blue for 25 bars
    
    
    p <- ggplot(data=plot_df, aes(x=X2, y=reorder(X1, X2), fill = X3)) +
      geom_bar(stat="identity", orientation = "y", color = 'black')+
      scale_x_continuous(expand = c(0, 0), limits = c(0, max(plot_df$X2)+0.01),
                         breaks = scales::pretty_breaks(n = 5))+
      theme_Publication() +
      theme(legend.text=element_text(size=16),legend.key.size = unit(3,"line"),legend.margin=margin(-10,25,25,-10),
            legend.box.margin=margin(-20,-20,-20,-20), #
            axis.text = element_text( size=30,family="Helvetica"),
            strip.text = element_text(face="bold", colour = "white",size=25,family="Helvetica"), 
            legend.title=element_blank(),axis.text.x = element_text(face = c('plain')),
            strip.background=element_rect(colour="black",fill="black"),
            plot.margin = grid::unit(c(5,5,5,-11), "mm")
            #aspect.ratio = 1/2
      )+
      xlab('') + ylab("") + scale_fill_manual("legend", values = c("A" ="#ef3b2c", "B" = "#386cb0"))+ 
      theme(legend.position="none")
    p 
    if (1==1){
      ggsave(file.path(backpack_VI[['directory_figures']],"VI_OOS_EW.png"),
             plot = p, dpi=150, dev='png', 
             #height=250, width=300, 
             height=150, width=250, 
             units="mm",scale = 1)
    }
  }
  
  
  
  
  
  
  # ----------------------------- Plot: GROUPED Shapley-Values: In-Sample -------------------------- #
  
  # --- MACE
  plot_df <- data.frame(matrix(data = NA, ncol = 3, nrow = 5)) #25 most important features
  plot_df[,1] <- names(MACE_groupshap_ins_global_abs)[1:5]   #variable names
  plot_df[,2] <- as.numeric(MACE_groupshap_ins_global_abs / max(MACE_groupshap_ins_global_abs))[1:5] #VI values
  plot_df[,3] <- c(c("A"),rep(c("B","A"),2)) #color codes for alternating red and blue for 25 bars
  plot_df <- na.omit(plot_df)
  
  plot_df[,1] <- gsub('CRSP_','',plot_df[,1])
  
  p <- ggplot(data=plot_df, aes(x=X2, y=reorder(X1, X2), fill = X3)) +
    geom_bar(stat="identity", orientation = "y", color = 'black')+
    scale_x_continuous(expand = c(0, 0), limits = c(0, max(plot_df$X2)+0.01),
                       breaks = scales::pretty_breaks(n = 5))+
    theme_Publication() +
    theme(legend.text=element_text(size=16),legend.key.size = unit(3,"line"),legend.margin=margin(-10,25,25,-10),
          legend.box.margin=margin(-20,-20,-20,-20), #
          axis.text = element_text( size=30,family="Helvetica"),
          strip.text = element_text(face="bold", colour = "white",size=25,family="Helvetica"), 
          legend.title=element_blank(),axis.text.x = element_text(face = c('plain')),
          strip.background=element_rect(colour="black",fill="black"),
          plot.margin = grid::unit(c(5,5,5,-11), "mm")
          #aspect.ratio = 1/2
    )+
    xlab('') + ylab("") + scale_fill_manual("legend", values = c("A" ="#ef3b2c", "B" = "#386cb0"))+ 
    theme(legend.position="none")
  p 
  if (1==1){
    ggsave(file.path(backpack_VI[['directory_figures']],"GroupedVI_INS_MACE.png"),
           plot = p, dpi=150, dev='png', 
           #height=250, width=300, 
           height=150, width=250,
           units="mm",scale = 1)
  }
  
  
  if (backpack_VI[['I_want_EW']]){
    
    # --- Equally-Weighted Portfolio
    plot_df <- data.frame(matrix(data = NA, ncol = 3, nrow = 5)) #25 most important features
    plot_df[,1] <- names(EW_groupshap_ins_global_abs)[1:5]   #variable names
    plot_df[,2] <- as.numeric(EW_groupshap_ins_global_abs / max(EW_groupshap_ins_global_abs))[1:5] #VI values
    plot_df[,3] <- c(c("A"),rep(c("B","A"),2)) #color codes for alternating red and blue for 25 bars
    plot_df <- na.omit(plot_df)
    
    plot_df[,1] <- gsub('CRSP_','',plot_df[,1])
    
    p <- ggplot(data=plot_df, aes(x=X2, y=reorder(X1, X2), fill = X3)) +
      geom_bar(stat="identity", orientation = "y", color = 'black')+
      scale_x_continuous(expand = c(0, 0), limits = c(0, max(plot_df$X2)+0.01),
                         breaks = scales::pretty_breaks(n = 5))+
      theme_Publication() +
      theme(legend.text=element_text(size=16),legend.key.size = unit(3,"line"),legend.margin=margin(-10,25,25,-10),
            legend.box.margin=margin(-20,-20,-20,-20), #
            axis.text = element_text( size=30,family="Helvetica"),
            strip.text = element_text(face="bold", colour = "white",size=25,family="Helvetica"), 
            legend.title=element_blank(),axis.text.x = element_text(face = c('plain')),
            strip.background=element_rect(colour="black",fill="black"),
            plot.margin = grid::unit(c(5,5,5,-11), "mm")
            #aspect.ratio = 1/2
      )+
      xlab('') + ylab("") + scale_fill_manual("legend", values = c("A" ="#ef3b2c", "B" = "#386cb0"))+ 
      theme(legend.position="none")
    p 
    if (1==1){
      ggsave(file.path(backpack_VI[['directory_figures']],"GroupedVI_INS_EW.png"),
             plot = p, dpi=150, dev='png', 
             #height=250, width=300, 
             height=150, width=250,
             units="mm",scale = 1)
    }
    
  }
  
  
  # ----------------------------- Plot: GROUPED Shapley-Values: Out-Of-Sample -------------------------- #
  
  
  # --- MACE
  plot_df <- data.frame(matrix(data = NA, ncol = 3, nrow = 5)) #25 most important features
  plot_df[,1] <- names(MACE_groupshap_oos_global_abs)[1:5]   #variable names
  plot_df[,2] <- as.numeric(MACE_groupshap_oos_global_abs / max(MACE_groupshap_oos_global_abs))[1:5] #VI values
  plot_df[,3] <- c(c("A"),rep(c("B","A"),2)) #color codes for alternating red and blue for 25 bars
  plot_df <- na.omit(plot_df)
  
  plot_df[,1] <- gsub('CRSP_','',plot_df[,1])
  
  p <- ggplot(data=plot_df, aes(x=X2, y=reorder(X1, X2), fill = X3)) +
    geom_bar(stat="identity", orientation = "y", color = 'black')+
    scale_x_continuous(expand = c(0, 0), limits = c(0, max(plot_df$X2)+0.01),
                       breaks = scales::pretty_breaks(n = 5))+
    theme_Publication() +
    theme(legend.text=element_text(size=16),legend.key.size = unit(3,"line"),legend.margin=margin(-10,25,25,-10),
          legend.box.margin=margin(-20,-20,-20,-20), #
          axis.text = element_text( size=30,family="Helvetica"),
          strip.text = element_text(face="bold", colour = "white",size=25,family="Helvetica"), 
          legend.title=element_blank(),axis.text.x = element_text(face = c('plain')),
          strip.background=element_rect(colour="black",fill="black"),
          plot.margin = grid::unit(c(5,5,5,-11), "mm")
          #aspect.ratio = 1/2
    )+
    xlab('') + ylab("") + scale_fill_manual("legend", values = c("A" ="#ef3b2c", "B" = "#386cb0"))+ 
    theme(legend.position="none")
  p 
  if (1==1){
    ggsave(file.path(backpack_VI[['directory_figures']],"GroupedVI_OOS_MACE.png"),
           plot = p, dpi=150, dev='png', 
           #height=250, width=300, 
           height=150, width=250,
           units="mm",scale = 1)
  }
  
  
  if (backpack_VI[['I_want_EW']]){
    
    # --- Equally-Weighted Portfolio
    plot_df <- data.frame(matrix(data = NA, ncol = 3, nrow = 5)) #25 most important features
    plot_df[,1] <- names(EW_groupshap_oos_global_abs)[1:5]   #variable names
    plot_df[,2] <- as.numeric(EW_groupshap_oos_global_abs / max(EW_groupshap_oos_global_abs))[1:5] #VI values
    plot_df[,3] <- c(c("A"),rep(c("B","A"),2)) #color codes for alternating red and blue for 25 bars
    plot_df <- na.omit(plot_df)
    
    plot_df[,1] <- gsub('CRSP_','',plot_df[,1])
    
    p <- ggplot(data=plot_df, aes(x=X2, y=reorder(X1, X2), fill = X3)) +
      geom_bar(stat="identity", orientation = "y", color = 'black')+
      scale_x_continuous(expand = c(0, 0), limits = c(0, max(plot_df$X2)+0.01),
                         breaks = scales::pretty_breaks(n = 5))+
      theme_Publication() +
      theme(legend.text=element_text(size=16),legend.key.size = unit(3,"line"),legend.margin=margin(-10,25,25,-10),
            legend.box.margin=margin(-20,-20,-20,-20), #
            axis.text = element_text( size=30,family="Helvetica"),
            strip.text = element_text(face="bold", colour = "white",size=25,family="Helvetica"), 
            legend.title=element_blank(),axis.text.x = element_text(face = c('plain')),
            strip.background=element_rect(colour="black",fill="black"),
            plot.margin = grid::unit(c(5,5,5,-11), "mm")
            #aspect.ratio = 1/2
      )+
      xlab('') + ylab("") + scale_fill_manual("legend", values = c("A" ="#ef3b2c", "B" = "#386cb0"))+ 
      theme(legend.position="none")
    p 
    if (1==1){
      ggsave(file.path(backpack_VI[['directory_figures']],"GroupedVI_OOS_EW.png"),
             plot = p, dpi=150, dev='png', 
             #height=250, width=300, 
             height=150, width=250,
             units="mm",scale = 1)
    }
    
  }
  
  
  
  
  
  # ---------------------------------------------------------------------------------------------- #
  #
  #                               Scatter-Plot (Figure 9a)
  #
  # ---------------------------------------------------------------------------------------------- #
  
  # --- Which feature will be plotted?
  my_features_vec <- list()
  for (ff in backpack_VI[['scatter_features']]){
    my_features_vec[[ff]] <- colnames(backpack_data[['X_train']])[grep(ff,colnames(backpack_data[['X_train']]))]
  }
  
  
  
  
  # ---------- Calculate the Most-Important Feature in Each Period: Out-Of-Sample -------------------- #
  
  grouped_vars <- gsub("L1_","",colnames(MACE_shap_oos_local)[grepl("L1_",colnames(MACE_shap_oos_local))])
  grouped_vars <- gsub("FD_","",grouped_vars)
  
  plot_df_oos <- data.frame('time'=oos_period)
  plot_df_oos[,paste0('MACE_',grouped_vars)] <- NA
  for (rr in 1:nrow(plot_df_oos)){
    
    # --- Get Most-Important Feature (MIF)
    mace_mif_rr <- MACE_shap_oos_local[rr,]
    
    # --- Get the Importance by 'group'
    mace_grouped_mif_rr <- setNames(rep(NA,times=length(grouped_vars)),grouped_vars)
    
    for (gg in grouped_vars){
      mace_grouped_mif_rr[gg] <- sum(mace_mif_rr[grepl(gg,names(mace_mif_rr))])
    }
    
    # --- Insert the top MIF into the data frame
    plot_df_oos[rr, paste0('MACE_',grouped_vars)] <- mace_grouped_mif_rr[grouped_vars]
    
  }
  
  # --- Add the real series
  for (gg in grouped_vars){
    cols_gg <- grepl(gg,colnames(backpack_data[['X_test']]))
    plot_df_oos[,gg] <- apply(backpack_data[['X_test']][,cols_gg],1,mean)
  }
  
  
  
  # ---------- Do the Scatter-Plot for each of your desired features -------------------- #
  
  for (ff in backpack_VI[['scatter_features']]){
    
    plot_df_ins <- data.frame('mace_shap_ins'=MACE_groupshap_ins_local[[ff]],
                              'X' = apply(backpack_data[['X_train']][,my_features_vec[[ff]]],1,mean))
    
    
    
    
    plot_df_final <- data.frame(feature=log(c(plot_df_ins$X,plot_df_oos[,ff])*100),
                                'MACE_shap'=c(plot_df_ins$mace_shap_ins,plot_df_oos[,paste0('MACE_',ff)]),
                                'sample'=c(rep('ins',nrow(plot_df_ins)),
                                           rep('oos',nrow(plot_df_oos))))
    
    # --- Exclude In-Sample observations from the fit
    plot_df_final$weight <- 1
    plot_df_final$weight[which(plot_df_final$sample == 'ins')] <- NA
    
    
    scaleFUN_mmyyyy <- function(x){
      return(paste0(substr(x,6,7),'/',substr(x,1,4)))
    }
    
    my_graph <- ggplot(plot_df_final,aes(x=feature,y=MACE_shap)) + 
      geom_point(aes(color=sample), size=5) + 
      geom_smooth(method = 'loess',se=F,fullrange=T,colour='orange', fill = "orange", 
                  mapping=aes(weight=weight)) +
      xlab('')+ylab('')+labs(color='',
                             title=paste0('OOS Period: ',
                                          oos_period[1],
                                          ' - ',oos_period[length(oos_period)]))+
      
      theme(axis.text.x=element_text(size=24,angle = 0,hjust=1),
            axis.text.y=element_text(size=24),
            strip.text = element_text(face="bold", size=30),
            legend.text=element_text(size=30),
            legend.position='bottom') +
      scale_y_continuous(name='Shapley Value') +
      scale_x_continuous(name=paste0('log(',ff,' x 100)')) +
      scale_color_manual(values = c("ins" = "#386cb0", "oos" = "#ef3b2c")) +
      theme_Publication() +  
      theme(legend.text=element_text(size=14),legend.key.size = unit(3,"line"),
            legend.position = "",
            legend.margin=margin(-10,25,25,-10),
            legend.box.margin=margin(-40,-40,-40,-40),
            strip.text = element_text(face="bold", colour = "white",size=30,family="Helvetica"), #
            strip.background=element_rect(colour="black",fill="black"),
            plot.margin = grid::unit(c(5,5,5,5), "mm"),
            axis.title.x = element_text(angle=0)) + #grid::unit(c(5,11,5,-11), "mm")) + 
      guides(col=guide_legend(nrow=1,byrow=F)) 
    
    my_graph
    
    
    if (1==1){
      ggsave(file = file.path(backpack_VI[['directory_figures']],paste0("Scatter_GroupedShap_MACE_",ff,".png")), 
             plot = my_graph, device = "png",
             width = 27, height = 20, units = "cm", dpi = 150)
    }
    
    
    
    
  }
  
  
  
  if (backpack_VI[['I_want_EW']]){
    out <- list('MACE_shap_ins_local'=MACE_shap_ins_local,'MACE_shap_oos_local'=MACE_shap_oos_local,
                'EW_shap_ins_local'=EW_shap_ins_local,'EW_shap_oos_local'=EW_shap_oos_local)
  } else {
    out <- list('MACE_shap_ins_local'=MACE_shap_ins_local,'MACE_shap_oos_local'=MACE_shap_oos_local)
  }
  
  
  
  
  return(out)
  
  
}