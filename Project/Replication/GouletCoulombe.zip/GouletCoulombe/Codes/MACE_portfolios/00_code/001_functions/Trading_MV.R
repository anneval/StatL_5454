Trading_MV <- function(backpack_data,backpack_trading,h=1){
  
  # This function calculates in-sample and out-of-sample returns following a mean-variance optimizing investor, 
  # for the following portfolios:
  
  # --- Part I:     Portfolios that you specify in 'backpack_trading['my_portfolios_name']', e.g.:
  #         1. MACE:          Predictions are made based on Random-Forest fed with Macro-Predictors from Welch & Goyal (2008)
  
  # --- Part II:    The following portfolios will ALWAYS be computed:
  #         2. 'PM'-versions of 'Part I':     Predictions are made based on a rolling-mean of all portfolios specified in backpack_trading['my_portfolios_name']'
  #         3. EW (RF):                       An equally-weighted portfolio of stocks in 'Y' with predictions being based on 
  #                                           Random-Forest fed with Macro-Predictors from Welch & Goyal (2008)
  #         4. EW (PM):                       An equally-weighted portfolio of stocks in 'Y' with predictions being based on a rolling-mean 
  #         5. SP500 (RF):                    The S&P 500 with predictions being based on a Random-Forest fed with Macro-Predictors from Welch & Goyal (2008)
  #         6. SP500 (PM):                    The S&P 500 with predictions being based on a rolling-mean
  
  
  
  # ------------------------------------ Couple of Checks up front ---------------------------------------- #
  
  test <- unique(length(backpack_trading[['my_portfolios_name']]),
                 length(backpack_trading[['my_portfolios_weights']]),
                 length(backpack_trading[['my_portfolios_predictions_OOS']]))
  
  
  if (length(test) > 1){
    stop('Mi dispiace: Number of Portfolios != Number of Sets of corresponding Weights')
  } else {
    print("Checks Successful! Vai vai vai! Forza Napoli!")
  }
  
  # ---------------------------------------------------------------------------------------------- #
  
  
  
  # --- How many portfolios are user-specified?
  N_portfolios <- length(backpack_trading[['my_portfolios_name']])
  
  # --- Trade the following portfolios:
  portfolio_names <- c(backpack_trading[['my_portfolios_name']],
                       paste0(backpack_trading[['my_portfolios_name']],' (PM)'),
                       'EW (RF)', 'EW (PM)', 'SP500 (RF)', 'SP500 (PM)')
  
  # --- Unpack the data
  X_train <- backpack_data[['X_train']]
  X_test <- backpack_data[['X_test']]
  
  Y_train <- backpack_data[['Y_train']]
  Y_test <- backpack_data[['Y_test']]
  
  
  # --- Get the time-dimensions of the respective sets:
  TT_train <- dim(X_train)[1]
  TT_test <- dim(X_test)[1]
  
  
  # --- Storage for Portfolio Returns: Out-Of-Sample -- Trading following Mean-Variance optimization
  df_MV_R_Blist <- setNames(rep(list(data.frame(matrix(NA,
                                                       nrow=TT_test,
                                                       ncol=backpack_hyps[['B']],
                                                       dimnames=list(c(),paste0("B",c(1:backpack_hyps[['B']])))))),
                                times=length(backpack_trading[['my_portfolios_name']])*2), 
                            c(backpack_trading[['my_portfolios_name']],
                              paste0(backpack_trading[['my_portfolios_name']], ' (PM)'))) 
  
  
  # --- Storage for Portfolio Returns: Out-Of-Sample -- Trading following Mean-Variance optimization
  df_MV_R <- data.frame(matrix(NA,nrow=TT_test,
                               ncol=length(portfolio_names)+1,
                               dimnames=list(c(),c('time',portfolio_names))),check.names = F)
  df_MV_R['time'] <- backpack_data$time[(length(backpack_data$time)-nrow(backpack_data$Y_test)+1):length(backpack_data$time)]
  
  
  # --- Storage for Predictions of Equally-Weighted Portfolio & S&P 500
  df_pred_EW_SP500 <- data.frame(matrix(NA,nrow=TT_test,ncol=5,
                                        dimnames=list(c(),c('time','EW (RF)', 'EW (PM)', 'SP500 (RF)', 'SP500 (PM)'))),check.names = F)
  df_pred_EW_SP500['time'] <- backpack_data$time[(length(backpack_data$time)-nrow(backpack_data$Y_test)+1):length(backpack_data$time)]
  
  
  # --- Collect the parameters for your Mean-Variance Optimization: risk-tolerance, leverage, etc.
  params_MV <- list("lookback"=backpack_trading[['MV_lookback']],
                    "gamma"=backpack_trading[['MV_gamma']],
                    "alpha"=backpack_trading[['MV_alpha']],
                    "MV_pos_min"=backpack_trading[['MV_pos_min']],
                    "MV_pos_max"=backpack_trading[['MV_pos_max']])
  
  
  
  # ============================================================================================== #
  #
  #                  Trading:   Portfolios in backpack_trading['my_portfolios_name']
  #
  # ============================================================================================== #
  
  
  for (nn in 1:N_portfolios){
    
    # --- Get the weights for portfolio 'nn'
    weights_nn <- backpack_trading[['my_portfolios_weights']][[nn]]
    
    for (bags in backpack_trading[['B']]){
      
      # --- Get the weights for portfolio 'nn' for bag 'bags'
      weights_nn_b <- as.numeric(weights_nn[bags,])
      
      
      
      # -------------------------- Portfolio: In-Sample Realized Returns  -------------------------------- #
      return_ins <- as.vector(Y_train %*% weights_nn_b)
      
      
      # -------------------------- Portfolio: Out-of-Sample Buy & Hold - Realized Returns -------------------------------- #
      return_oos_BH <- as.vector(Y_test %*% weights_nn_b)
      
      
      # -------------------------- Portfolio: Out-of-Sample Predictions  -------------------------------- #
      return_oos_pred <- backpack_trading[['my_portfolios_predictions_OOS']][[nn]][[bags]] 
      
      # -------------------------- Portfolio: Out-of-Sample Predictions (Prevailing Mean) -------------------------------- #
      return_oos_pred_PM <- roll_mean(series_oos=return_oos_BH,
                                      series_ins=return_ins,
                                      lookback=backpack_trading[['MV_lookback']],h)
      
      
      # -------------------------- Mean-Variance Exercise  -------------------------------- #
      # --- Portfolio
      MV_out <- MeanVariance(return_oos_BH,return_oos_pred,return_ins,params_MV)
      MV_return <- MV_out$return
      # --- Portfolio (Prevailing Mean)
      MV_out_PM <- MeanVariance(return_oos_BH,return_oos_pred_PM,return_ins,params_MV)
      MV_return_PM <- MV_out_PM$return
      
      
      # --------------------- Store the Out-of-Sample Returns for the current 'bag' ------------------------ #
      
      df_MV_R_Blist[[backpack_trading[['my_portfolios_name']][nn]]][,paste0('B',bags)] <- MV_return
      df_MV_R_Blist[[paste0(backpack_trading[['my_portfolios_name']][nn],' (PM)')]][,paste0('B',bags)] <- MV_return_PM
      
    }
    
    
    
    # -------------------------- Store the Out-of-Sample Returns  -------------------------------- #
    df_MV_R[backpack_trading[['my_portfolios_name']][nn]]  <- apply(df_MV_R_Blist[[backpack_trading[['my_portfolios_name']][nn]]],1,mean)
    df_MV_R[paste0(backpack_trading[['my_portfolios_name']][nn],' (PM)')] <- apply(df_MV_R_Blist[[paste0(backpack_trading[['my_portfolios_name']][nn],' (PM)')]],1,mean)
    
  }
  
  
  
  
  # ============================================================================================== #
  #
  #                  Trading:   Equally-Weighted Portfolio + S&P 500
  #
  # ============================================================================================== #
  
  # --------------------------------------------------------------------------------------------------------- #
  #
  #                         Prepare the Equally-Weighted Portfolio: Realized Returns
  #
  # --------------------------------------------------------------------------------------------------------- #
  
  EW_return_ins_BH <- apply(Y_train,1,mean)
  EW_return_oos_BH <- apply(Y_test,1,mean)
  
  
  # --------------------------------------------------------------------------------------------------------- #
  #
  #                                 Prepare the S&P 500
  #
  # --------------------------------------------------------------------------------------------------------- #
  
  # --- Load Welch & Goyal (2008)
  load(file.path(backpack_trading[['directory']],'10_data/GW08.RData'))
  
  
  # --- --- Extract: OOS-Period
  GW08_oos_idx <- c((nrow(GW08)-nrow(Y_test)+1):nrow(GW08))
  
  # --- --- Extract: In-Sample Period
  GW08_ins_idx <- c((nrow(GW08)-nrow(Y_train)-nrow(Y_test)+1):(nrow(GW08)-nrow(Y_test)))
  
  # --- Get the REALIZED S&P 500 excess returns --> we use the S&P 500 including dividends
  SP500_return_ins_BH <- series_transform(series=GW08$CRSP_SPvw,'MA',h)[GW08_ins_idx] - GW08$Rfree[GW08_ins_idx]
  SP500_return_oos_BH <- series_transform(series=GW08$CRSP_SPvw,'MA',h)[GW08_oos_idx] - GW08$Rfree[GW08_oos_idx]
  
  
  
  # --------------------------------------------------------------------------------------------------------- #
  #
  #                         Predictions (Prevailing Mean): Equally-Weighted + S&P 500
  #
  # --------------------------------------------------------------------------------------------------------- #
  
  EWpm_return_oos_pred <- roll_mean(series_oos=EW_return_oos_BH,series_ins=EW_return_ins_BH,
                                    backpack_trading[['MV_lookback']],h)
  SP500pm_return_oos_pred <- roll_mean(series_oos=SP500_return_oos_BH,series_ins=SP500_return_ins_BH,
                                       backpack_trading[['MV_lookback']],h)
  
  
  # ----------------------------------- Store OOS-predictions ----------------------------------- #
  df_pred_EW_SP500['EW (PM)'] <- EWpm_return_oos_pred
  df_pred_EW_SP500['SP500 (PM)'] <- SP500pm_return_oos_pred
  
  
  # --------------------------------------------------------------------------------------------------------- #
  #
  #                         Predictions (Random Forest): Equally-Weighted + S&P 500
  #
  # --------------------------------------------------------------------------------------------------------- #
  
  
  # --- Create Regression-Matrix
  ddd_sp500 = as.data.frame(cbind(z=SP500_return_ins_BH,X_train))
  colnames(ddd_sp500)[1]='z'
  ddd_ew = as.data.frame(cbind(z=EW_return_ins_BH,X_train))
  colnames(ddd_ew)[1]='z'
  
  # --- Draw blocks of observations for Out-Of-Bag computations
  bs=block.sampler(X_train,sampling_rate=0.8,block_size=backpack_trading[['my_blocksize']], num.tree=backpack_trading[['my_trees']])
  
  
  # ------------------------------------- Plant & Grow the Trees ----------------------------------- #
  r1_sp500 <- ranger(z ~ ., data = ddd_sp500,num.trees=backpack_trading[['my_trees']],inbag=bs$inbag1, 
                     mtry = round((ncol(ddd_sp500)-1)/backpack_trading[['mtry_denom']]),
                     #sample.fraction = 0.5,replace = F,
                     min.node.size = backpack_trading[['my_minnodesize']],num.threads = 3)
  
  r1_ew <- ranger(z ~ ., data = ddd_ew,num.trees=backpack_trading[['my_trees']],inbag=bs$inbag1, 
                  mtry = round((ncol(ddd_ew)-1)/backpack_trading[['mtry_denom']]),
                  #sample.fraction = 0.5,replace = F,
                  min.node.size = backpack_trading[['my_minnodesize']],num.threads = 3)  
  
  
  # ----------------------------------- Make OOS-predictions ----------------------------------- #
  SP500rf_return_oos_pred <- predict(r1_sp500, data = as.data.frame(X_test))$predictions
  EWrf_return_oos_pred <- predict(r1_ew, data = as.data.frame(X_test))$predictions
  
  
  # ----------------------------------- Store OOS-predictions ----------------------------------- #
  df_pred_EW_SP500['EW (RF)'] <- EWrf_return_oos_pred
  df_pred_EW_SP500['SP500 (RF)'] <- SP500rf_return_oos_pred
  
  
  # --------------------------------------------------------------------------------------------------------- #
  #
  #                                         Mean-Variance Exercise
  #
  # --------------------------------------------------------------------------------------------------------- #
  
  
  # ------------------------------------ Equally-Weighted Portfolios  --------------------------------------- #
  
  MV_out_EWrf <- MeanVariance(return_oos_true=EW_return_oos_BH, 
                              return_oos_pred = EWrf_return_oos_pred,
                              return_ins=EW_return_ins_BH,
                              params_MV)
  MV_return_EWrf <- MV_out_EWrf$return
  
  MV_out_EWpm <- MeanVariance(EW_return_oos_BH,EWpm_return_oos_pred,EW_return_ins_BH,params_MV)
  MV_return_EWpm <- MV_out_EWpm$return
  
  # ----------------------------------------------- S&P 500  ------------------------------------------------- #
  
  MV_out_SP500rf <- MeanVariance(return_oos_true=SP500_return_oos_BH, 
                                 return_oos_pred = SP500rf_return_oos_pred,
                                 return_ins=SP500_return_ins_BH,
                                 params_MV)
  MV_return_SP500rf <- MV_out_SP500rf$return
  
  MV_out_SP500pm <- MeanVariance(SP500_return_oos_BH,SP500pm_return_oos_pred,SP500_return_ins_BH,params_MV)
  MV_return_SP500pm <- MV_out_SP500pm$return
  
  
  # -------------------------- Store the Out-of-Sample Returns  -------------------------------- #
  df_MV_R['EW (RF)']  <- MV_return_EWrf
  df_MV_R['EW (PM)']  <- MV_return_EWpm
  df_MV_R['SP500 (RF)']  <- MV_return_SP500rf
  df_MV_R['SP500 (PM)']  <- MV_return_SP500pm
  
  
  out <- list('MV_returns'=df_MV_R,'Predictions_EW_SP500'=df_pred_EW_SP500,'EW_ranger'=r1_ew)
  
  
  return(out)
  
  
}