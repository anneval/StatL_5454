theme_Publication <- function(base_size=30, base_family="Arial") {
  library(grid)
  library(ggthemes)
  library(ggthemes)
  library(DescTools)
  (theme_foundation(base_size=base_size, base_family=base_family)
    + theme(plot.title = element_text(face = "bold",
                                      size = rel(1.3), hjust = 0.5),
            text = element_text(),
            panel.background = element_rect(colour = NA),
            plot.background = element_rect(colour = NA),
            panel.border = element_rect(colour = 'black'),
            axis.title = element_text(face = "bold",size = rel(1)),
            axis.title.y = element_text(angle=90,vjust =2),
            axis.title.x = element_text(angle=45,vjust = -0.2),
            axis.text = element_text(),
            axis.line = element_line(colour="black"),
            axis.ticks = element_line(),
            panel.grid.major = element_line(colour="#f0f0f0"),
            panel.grid.minor = element_blank(),
            legend.key = element_rect(colour = NA),
            legend.position = "bottom",
            legend.direction = "horizontal",
            legend.key.size= unit(0.6, "cm"),
            #legend.margin = unit(0, "cm"),
            legend.margin=margin(-20,5,5,-20),
            legend.box.margin=margin(-5,-5,-5,-5),
            #legend.text=element_text(size=12),
            legend.title = element_text(face="italic"),
            #plot.margin=unit(c(5,5,5,5),"mm"),
            strip.background=element_rect(colour="#f0f0f0",fill="#f0f0f0"),
            strip.text = element_text(face="bold")
    ))
  
}


break_function = function(x) {
  # if(x[2]*x[1]<0){ #gotta include zero
  
  #target=7
  #for(i in 3:20){
  i=6
  init = seq(from = x[1], to = x[2], length.out = i)
  ll = abs(init[2]-init[1])
  candi = c(0.005,0.01,0.05,0.1,0.2,0.25,0.5,1,2,2.5,5,10)
  gapchoice=candi[which.min(abs(ll-candi))]
  xnew = RoundTo(x,gapchoice)
  if(xnew[1]>x[1]){xnew[1]-gapchoice}
  if(xnew[2]<x[2]){xnew[2]+gapchoice}
  thisshit=seq(from = xnew[1], to = xnew[2], by = gapchoice)
  #if(length(thisshit)==target){finalshit=thisshit}
  #print(length(thisshit))
  #}
  # }
  #unique(RoundTo(sort(append(0,)),multiple=0.05))
  return(thisshit)
}