#################################################################################################################
#
#
#                                 MAXIMALLY MACHINE LEARNABLE PORTFOLIOS
#
#                 1.    MACE - Estimation
#                 2.    Trading
#                 3.    Variable Importance (VI) --- Shapley Values
#
#
#################################################################################################################
rm(list = ls())

install.packages('fastshap')
install.packages("DescTools")

library(lubridate)
library(dplyr)
library(ranger)
library(glmnet)
library(RColorBrewer)
library(fastshap)
library(DescTools)

set.seed(123)

backpack_hyps <- list()
backpack_trading <- list()

# =================================== USER INTERACTION ========================================= #


# ------------------------- Set your directory to the main folder -------------------- #
directory <- '/Users/maximilian/Dropbox/GCS_SIDEsummerschool_codes/GouletCoulombe/Goebel_MMLP/'


backpack_trading['directory'] <- directory

# -------------------------- Parameters: Bagging ------------------------------------- #

# --- How many Bags do you want to pack? 
#     ---> If you do not wish to run a bagging strategy, set B=1
backpack_hyps['B'] <- 1


# -------------------------- Parameters: MACE ------------------------------------- #

# --- Set the Block-Size (an integer for the number of observations to be sampled in blocks) for the 'block.sampler':
backpack_hyps['my_blocksize'] <- 24

# --- Global Hyperparameters
# --- --- Do you want to tune "lambda" via cross-validation?
backpack_hyps['I_want_cv'] <- F
# --- --- How many iterations?
backpack_hyps['maxit'] <- 100
# --- --- Outer-Learning-Rate:
backpack_hyps['lr'] <- 0.1


# --- RHS: Random Forest
# --- --- How many trees do you wanna plant?
backpack_hyps['my_trees'] <- 500
backpack_trading['my_trees'] <- backpack_hyps['my_trees']
# --- --- Set the min.node.size:
backpack_hyps['my_minnodesize'] <- 20
# --- --- 'mtry' will be: ncol(X)/mtry_denom ---> Set 'mtry_denom':
backpack_hyps['mtry_denom'] <- 3


# --- LHS: glmnet
# --- --- Type of Regularization? [0 = Ridge; 1 = LASSO]
backpack_hyps['my_alpha'] <- 0.0
# --- --- Set "lambda" manually. (Overwritten if I_want_cv == TRUE or I_want_lambda_targeting == TRUE)
backpack_hyps['my_lambda'] <- 0.01
# --- --- Lower-bound on glmnet-betas? [-Inf;Inf]
backpack_hyps['my_lowerbound'] <- 0
# --- --- Do you want to impose a stock-specific penalty (SD of a given stock-return series)?
backpack_hyps['I_want_stockspecificpenalty'] <- T
# --- --- --- Do you want to safeguard against any market-frenzy?
backpack_hyps['I_want_penalty_frenzy'] <- F
# --- --- Do you want to weight individual observations?
backpack_hyps['I_want_obsweight'] <- T
# --- Do you want an intercept?
backpack_hyps['I_want_intercept'] <- T
# --- Do you want to set some unconditional portfolio-return different from 0?
backpack_hyps['c0'] <- 0/12
if (!(backpack_hyps['c0'] == 0)){
  backpack_hyps['I_want_intercept'] <- F
}

# --- --- LHS: lambda-targeting
# --- --- Do you want Lambda-Targeting?
backpack_hyps['I_want_lambda_targeting'] <- F
# --- --- --- How do you want to target lambda? By a pre-defined R2? By the highest 'dev.ratio'? ['R2','dev_ratio']
backpack_hyps['my_lambda_target'] <- 'R2'
# --- --- --- In case you chose: 'my_lambda_target==R2', what's the R2 that you are targeting? [admissible values: 0,...,1]
backpack_hyps['my_R2_target'] <- 0.05



# --- Do you want Early-Stopping? 
#     ---> Based on RMSE of Validation Set 
#     ---> If there is NO Validation Set: based on RMSE of Training Set
backpack_hyps['I_want_ES'] <- FALSE 

# --- --- What is your patience-period for ES to get triggered?
backpack_hyps['ES_patience'] <- 100



# -------------------------- Parameters: Portfolio-Evaluation ---------------------- #

# --- Define the minimum and maximum position you are willing to trade your portfolio your portfolio
backpack_trading['MV_pos_max'] <- 2
backpack_trading['MV_pos_min'] <- -1

# --- What is the lookback-period for calculating the prevailing mean?
backpack_trading['MV_lookback'] <- 240

# --- for the Mean-Variance-Portfolio Exercise:
# --- --- 'Gamma' = Coefficient of Relative Risk Aversion 
# --- --- 'Alpha' = Decay-Parameter for computing the Exponentially-Weighted Moving-Average of the Portfolio-Variance
backpack_trading['MV_gamma'] <- 3
backpack_trading['MV_alpha'] <- 0.94


# ============================================================================================== #




# ============================================================================================== #
#
#                             00.   Load the Data & Auxiliary Functions
#
# ============================================================================================== #

# --- Load MACE
source(file.path(directory,"00_code/001_functions/MACE.R"))

# --- Load the function for Trading
source(file.path(directory,"00_code/001_functions/Trading_MV.R"))

# --- Load the function for Variable Importance
source(file.path(directory,"00_code/001_functions/MACE_VI.R"))


# --- Load some helper functions
source(file.path(directory,"00_code/001_functions/auxiliaries.R"))


# --- Load the data: Returns: Gu, Kelly, Xiu (2020); Predictors: Welch, Goyal (2008)
#     ---> data is already in the following format:
#          'Y' & 'Ytest': t+1 ---> already in EXCESS of the risk-free rate
#          'X' & 'Xtest': t
load(file.path(directory,'10_data/GKX2020_GW08_200601.RData'))


# -------------------------------------- Pack the Data ----------------------------------------------- #

backpack_data <- list()

# --- Feature-Set: Training-Data  (format:  data.frame)
backpack_data[['X_train']] = data[['X']]

# --- Feature-Set: Test-Data  (format: data.frame)
backpack_data[['X_test']] = data[['Xtest']]

# --- Labels: Training-Data  (format:  matrix)
backpack_data[['Y_train']] = data[['Y']]

# --- Feature-Set: Test-Data  (format: matrix)
backpack_data[['Y_test']] = data[['Ytest']]

# --- Dates:
backpack_data[['time']] = data[['time']]



#############################################################################################################
#
#                              1.       MACE - Estimation
#
############################################################################################################

# -------------------------------------- MACE ----------------------------------------------- #

MACE_out <- MACE(backpack_data,backpack_hyps)




############################################################################################################
#
#                              2.       Trading
#
############################################################################################################


# =================================== USER INTERACTION ========================================= #


# --- Insert the name of the portfolios you want to trade:
backpack_trading['my_portfolios_name'] <- c('MACE')


# --- Insert the weights for each portfolio that you want to trade:
backpack_trading[['my_portfolios_weights']] <- list('MACE' = MACE_out$df_MACE_weights_Bdf)


# --- Insert the Out-Of-Sample predictions for your portfolio
backpack_trading[['my_portfolios_predictions_OOS']] <- list('MACE' = MACE_out$df_pred_Blist$Test$MACE)


# =================================== USER INTERACTION ========================================= #





# ----------------------- Copy some of the parameters that went into MACE ---------------------- #

backpack_trading['B'] <- backpack_hyps['B']
backpack_trading['my_blocksize'] <- backpack_hyps['my_blocksize']
backpack_trading['my_minnodesize'] <- backpack_hyps['my_minnodesize']
backpack_trading['mtry_denom'] <- backpack_hyps['mtry_denom']

# ---------------------------------------------------------------------------------------------- #





# -------------------------------------- Trading ----------------------------------------------- #

Trading_out <- Trading_MV(backpack_data,backpack_trading,h=1)



# ----------------------------------- Post-Trading Evaluation --------------------------------------------- #

# --- Annualized Average Return
print(paste0('Annualized Return -- S&P 500 (RF): ', round(annualized_return(Trading_out$MV_returns[['SP500 (RF)']],1/12)*100,1), '%'))
print(paste0('Annualized Return -- EW (RF):      ', round(annualized_return(Trading_out$MV_returns[['EW (RF)']],1/12)*100,1), '%'))
print(paste0('Annualized Return -- MACE:         ', round(annualized_return(Trading_out$MV_returns[['MACE']],1/12)*100,1), '%'))
print(paste0('Annualized Return -- MACE (PM):    ', round(annualized_return(Trading_out$MV_returns[['MACE (PM)']],1/12)*100,1), '%'))

# --- Sharpe Ratio
print(paste0('Sharpe Ratio -- S&P 500 (RF): ', round(sharpe_ratio(Trading_out$MV_returns[['SP500 (RF)']],1/12),3)))
print(paste0('Sharpe Ratio -- EW (RF):      ', round(sharpe_ratio(Trading_out$MV_returns[['EW (RF)']],1/12),3)))
print(paste0('Sharpe Ratio -- MACE:         ', round(sharpe_ratio(Trading_out$MV_returns[['MACE']],1/12),3)))
print(paste0('Sharpe Ratio -- MACE (PM):    ', round(sharpe_ratio(Trading_out$MV_returns[['MACE (PM)']],1/12),3)))



# ============================================================================================== #
#
#                         Plotting:     Cumulative Returns
#
# ============================================================================================== #



library(ggplot2)
scaleFUN <- function(x) sprintf("%.2f", x)


# ----------------------------- Get U.S. Recession Dates on a Monthly Frequency ----------------------------- #
NBER_Recessions <- nber(year(data$time[1]),year(tail(data$time,1))+1,freq=12)
NBER_Recessions_dates <- data.frame(matrix(NA,nrow=nrow(NBER_Recessions),ncol=ncol(NBER_Recessions),
                                           dimnames=list(c(),colnames(NBER_Recessions))))

# --- Transform from decimals to dates
for (rr in 1:nrow(NBER_Recessions)){
  for (cc in 1:ncol(NBER_Recessions)){
    NBER_Recessions_dates[rr,cc] <- format(date_decimal(NBER_Recessions[rr,cc]), "%Y-%m-%d")
    
  }
}

NBER_Recessions_dates$start <- as.Date(NBER_Recessions_dates$start, format = "%Y-%m-%d")
NBER_Recessions_dates$end <- as.Date(NBER_Recessions_dates$end, format = "%Y-%m-%d")


# ----------------------------- Collect the Cumulative Returns ----------------------------- #
plot_df <- data.frame("time"=Trading_out$MV_returns[['time']], 
                      "MACE"=cumsum(Trading_out$MV_returns[['MACE']]),
                      "MACEpm"=cumsum(Trading_out$MV_returns[['MACE (PM)']]),
                      "SP500pm"=cumsum(Trading_out$MV_returns[['SP500 (PM)']]),
                      "SP500rf"=cumsum(Trading_out$MV_returns[['SP500 (RF)']]),
                      "EWpm"=cumsum(Trading_out$MV_returns[['EW (PM)']]),
                      "EWrf"=cumsum(Trading_out$MV_returns[['EW (RF)']]))




# ----------------------------- Go Plotting! ----------------------------- #

my_graph <- ggplot() +
  geom_line(data = plot_df,aes(x =time , y =EWrf, color="EW (RF)"), linewidth = 1.6) +
  geom_line(data = plot_df,aes(x =time , y =SP500pm, color="S&P 500 (PM)"), linewidth = 1.3) +
  geom_line(data = plot_df,aes(x =time , y =SP500rf, color="S&P 500 (RF)"), linewidth = 1.3) +
  geom_line(data = plot_df,aes(x =time , y =EWpm, color="EW (PM)"), linewidth = 1.6) +
  geom_line(data = plot_df,aes(x =time , y =MACEpm, color="MACE (PM)"), linewidth = 1.6) +
  geom_line(data = plot_df,aes(x =time , y =MACE, color="MACE"), linewidth = 1.6) + 
  geom_hline(yintercept=0, color="black", linewidth = 0.75) +
  theme_bw()+
  xlab('')+ylab('')+labs(color='')+
  theme(axis.text.x=element_text(size=24,angle = 0,hjust=1),
        axis.text.y=element_text(size=24),
        strip.text = element_text(face="bold", size=30),
        legend.text=element_text(size=30),
        legend.position='bottom') +
  scale_color_manual(breaks=c("MACE","MACE (PM)","EW (RF)","EW (PM)","S&P 500 (RF)","S&P 500 (PM)"),
                     values=c("MACE"="#ef3b2c",
                              "EW (PM)" ="#386cb0",
                              "MACE (PM)" ="orange",
                              "S&P 500 (PM)"="darkolivegreen",
                              "EW (RF)"=brewer.pal('Dark2',n=3)[1],
                              "S&P 500 (RF)" ="aquamarine3"
                     ),
                     labels=c("MACE","MACE (PM)","EW (RF)","EW (PM)","S&P 500 (RF)","S&P 500 (PM)"))+ 
  scale_y_continuous(breaks = function(x) break_function(x),labels=scaleFUN,
                     expand = c(0.00,0.00))+
  scale_x_date(breaks = scales::pretty_breaks(n = 8),date_labels = "%Y",
               expand = c(0.005,0.005), limits = c(plot_df$time[1],plot_df$time[nrow(plot_df)]))+
  geom_rect(data=NBER_Recessions_dates, aes(xmin=start, xmax=end, ymin=-Inf, ymax=+Inf), fill='pink', alpha=0.3)+
  theme_Publication() +  
  theme(legend.text=element_text(size=14),legend.key.size = unit(3,"line"),
        legend.position = "bottom",
        legend.margin=margin(-10,25,25,-10),
        legend.box.margin=margin(-40,-40,-40,-40),
        strip.text = element_text(face="bold", colour = "white",size=30,family="Helvetica"), #
        strip.background=element_rect(colour="black",fill="black"),
        plot.margin = grid::unit(c(5,11,5,-11), "mm")) + 
  guides(col=guide_legend(nrow=1,byrow=F)) 

my_graph


############################################################################################################
#
#                              3.       Variable Importance (VI) --- Shapley Values
#
#                 ---> only runs VI for a single "Bag", which you have to choose yourself
#
############################################################################################################


library(fastshap)
library(pracma)
library(ranger)
library(ggplot2)

set.seed(123)

backpack_VI <- list()
# =================================== USER INTERACTION ========================================= #

# --- Set the directory to the folder where to export the figures to:
backpack_VI[['directory_figures']] <- paste0(directory,'/20_figures')

# --- In case you selected a bagging-strategy, for which of the bags do you want VI to be computed? [integer only]
backpack_VI[['bag']] <- 1


# --- Insert here the output of the function call 'MACE':
backpack_VI[['MACE_out']] <- MACE_out


# --- Do you also want Variable Importance for Equally-weighted Portfolios? [TRUE;FALSE]
backpack_VI[['I_want_EW']] <- T


# --- Insert here the fitted Random-Forest for Equally-Weighted Portfolios that you get from 'Trading_MV'
backpack_VI[['EW_ranger']] <- Trading_out[['EW_ranger']]


# --- Which feature shall be plotted in the Scatter-Plot?
backpack_VI[['scatter_features']] <- 'svar'

# =================================== USER INTERACTION ========================================= #





# -------------------------------------- Variable Importance ------------------------------------------ #

VI_out <- MACE_VI(backpack_data,backpack_VI)
