######################################################################################################               		MAXIMALLY MACHINE LEARNABLE PORTFOLIOS
#
#			Goulet Coulombe, P. & Göbel, M. (2023)#####################################################################################################


% -------------------------------------------------------------------------------------------- %
			
				Folder Structure

% -------------------------------------------------------------------------------------------- %

	- 00_code:	this folder contains 

			- the main file: 	MACE_MMLP.R
			- auxiliary functions:	in subfolder '/001_functions'

	- 10_data:	this folder contains:

			- GKX2020_GW08_200601.RData:

				- 'X' / 'Xtest':	the set of predictors made up of 
						12 macro-stock-market variables from Welch & Goyal (2008) 
						and their corresponding 12 lags.
						The data has already undergone some transformations.

				- 'Y' / 'Ytest':	the set of stock-returns from Gu, Kelly, Xiu (2020)


				- Training set:	'X' and 'Y'
				- Test set:	'Xtest' and 'Ytest'

				- 'X' and 'Xtest' have timestamp t
				- 'Y' and 'Ytest' have timestamp t+1

	- 20_figures:	the folder where to store Variable Importance plots



% -------------------------------------------------------------------------------------------- %

			Remarks on the main file 	MACE_MMLP.R

% -------------------------------------------------------------------------------------------- %
			

The file contains three sections:

                 1.    MACE - Estimation                 2.    Trading                 3.    Variable Importance (VI) --- Shapley Values


Each section may contain a subsection called 'USER INTERACTION'. Here you can set your own hyperparameters,
Or bring in your own models.


E.g. in section 'Trading', you can insert any kind of additional portfolio that you wish. You only need to insert:

	- line 208:	portfolio weights for each stock in 'Y'
	- line 212:	time-series of out-of-sample predictions for your portfolio returns


					